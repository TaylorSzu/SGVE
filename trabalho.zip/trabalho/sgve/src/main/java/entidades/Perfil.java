package entidades;

public enum Perfil {
    ADMIN,
    PADRAO
}
