-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sgve
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `categoria` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Eletrônicos'),(2,'Roupas'),(3,'Alimentos'),(4,'Acessórios'),(5,'Eletrônicos'),(6,'Roupas'),(7,'Alimentos'),(8,'Acessórios');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_categoria` AFTER INSERT ON `categoria` FOR EACH ROW BEGIN
    INSERT INTO log_categoria (acao, categoria)
    VALUES ('INSERÇÃO', NEW.categoria);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_atualizacao_categoria` AFTER UPDATE ON `categoria` FOR EACH ROW BEGIN
    INSERT INTO log_categoria (acao, categoria)
    VALUES ('ATUALIZAÇÃO', NEW.categoria);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_exclusao_categoria` AFTER DELETE ON `categoria` FOR EACH ROW BEGIN
    INSERT INTO log_categoria (acao, categoria)
    VALUES ('EXCLUSÃO', OLD.categoria);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `log_categoria`
--

DROP TABLE IF EXISTS `log_categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_categoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acao` varchar(255) DEFAULT NULL,
  `categoria` varchar(255) DEFAULT NULL,
  `data_categoria` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_categoria`
--

LOCK TABLES `log_categoria` WRITE;
/*!40000 ALTER TABLE `log_categoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_produto`
--

DROP TABLE IF EXISTS `log_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acao` varchar(50) DEFAULT NULL,
  `codigo` int DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `fabricante` varchar(255) DEFAULT NULL,
  `estoque` int DEFAULT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `data_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_produto`
--

LOCK TABLES `log_produto` WRITE;
/*!40000 ALTER TABLE `log_produto` DISABLE KEYS */;
INSERT INTO `log_produto` VALUES (1,'ATUALIZAÇÃO',999999,'Relógio','Marca F',199,'Acessórios','2024-06-07 07:20:34'),(2,'ATUALIZAÇÃO',999999,'Relógio','Marca F',199,'Acessórios','2024-06-07 07:20:34');
/*!40000 ALTER TABLE `log_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_usuario`
--

DROP TABLE IF EXISTS `log_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acao` varchar(50) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `usuario` varchar(255) DEFAULT NULL,
  `perfil` varchar(50) DEFAULT NULL,
  `data_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_usuario`
--

LOCK TABLES `log_usuario` WRITE;
/*!40000 ALTER TABLE `log_usuario` DISABLE KEYS */;
INSERT INTO `log_usuario` VALUES (1,'EXCLUSÃO','Taylor Oliveira de Souza','TaylorSz1','ADMIN','2024-06-07 05:19:11'),(2,'INSERÇÃO','Christian','Coroa','ADMIN','2024-06-07 05:20:28'),(3,'EXCLUSÃO','Taylor Oliveira de Souza','TaylorSz1','ADMIN','2024-06-07 05:25:06'),(4,'EXCLUSÃO','Christian','Coroa','ADMIN','2024-06-07 05:25:13'),(5,'INSERÇÃO','Christian','Coroa','ADMIN','2024-06-07 05:25:58'),(6,'EXCLUSÃO','Christian','Coroa','ADMIN','2024-06-07 05:29:24'),(7,'INSERÇÃO','Christian','Coroa','PADRAO','2024-06-07 05:30:01'),(8,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:19:23'),(9,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:23:25'),(10,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:24:31'),(11,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:25:42'),(12,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:26:05'),(13,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:27:33'),(14,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:28:31'),(15,'EXCLUSÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:28:58'),(16,'INSERÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:37:31'),(17,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:47:55'),(18,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:49:08'),(19,'ATUALIZAÇÃO','Christian','Coroa','PADRAO','2024-06-07 06:50:42'),(20,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 06:51:00'),(21,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 07:02:26'),(22,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 07:19:58'),(23,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 07:21:03'),(24,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 07:22:48'),(25,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 07:26:12'),(26,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 07:59:38'),(27,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:23:17'),(28,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:24:20'),(29,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:25:02'),(30,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:27:56'),(31,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:29:49'),(32,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:47:33'),(33,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:47:47'),(34,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:48:12'),(35,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:49:35'),(36,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 08:54:13'),(37,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 09:01:03'),(38,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 09:09:14'),(39,'ATUALIZAÇÃO','Taylor Oliveira de Souza','TaylorSz','ADMIN','2024-06-07 09:11:57');
/*!40000 ALTER TABLE `log_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_venda`
--

DROP TABLE IF EXISTS `log_venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_venda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acao` varchar(50) DEFAULT NULL,
  `produto` varchar(255) DEFAULT NULL,
  `quantidade` int DEFAULT NULL,
  `valor_pago` decimal(10,2) DEFAULT NULL,
  `pagamento` varchar(255) DEFAULT NULL,
  `data_venda` date DEFAULT NULL,
  `data_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_venda`
--

LOCK TABLES `log_venda` WRITE;
/*!40000 ALTER TABLE `log_venda` DISABLE KEYS */;
INSERT INTO `log_venda` VALUES (1,'INSERÇÃO','Smartphone A24',5,1000.00,'Pix','2024-05-01','2024-06-07 03:30:53'),(2,'INSERÇÃO','Relógio',1,300.00,'Pix','2024-06-07','2024-06-07 07:20:34'),(3,'EXCLUSÃO','Relógio',1,300.00,'Pix','2024-06-07','2024-06-07 07:59:56');
/*!40000 ALTER TABLE `log_venda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` int DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `fabricante` varchar(255) DEFAULT NULL,
  `estoque` int DEFAULT NULL,
  `estoque_minimo` int DEFAULT NULL,
  `estoque_maximo` int DEFAULT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `preco_compra` decimal(10,2) DEFAULT NULL,
  `preco_venda` decimal(10,2) DEFAULT NULL,
  `unidade_medida` varchar(50) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,123456,'Smartphone','Samsung',50,5,100,'Eletrônicos',300,800.00,1200.00,'un','Smartphone de última geração'),(2,789012,'Notebook','Dell',30,5,50,'Eletrônicos',2500,2000.00,3000.00,'un','Notebook para trabalho e estudo'),(3,345678,'Smart TV','LG',20,5,30,'Eletrônicos',12000,1500.00,2500.00,'un','Smart TV 4K com sistema operacional WebOS'),(4,901234,'Fone de Ouvido Bluetooth','Sony',100,10,200,'Eletrônicos',300,150.00,250.00,'un','Fone de ouvido sem fio com cancelamento de ruído'),(5,111111,'Camiseta','Marca X',200,20,500,'Roupas',200,30.00,60.00,'un','Camiseta casual de algodão'),(6,222222,'Calça Jeans','Marca Y',150,30,300,'Roupas',500,80.00,120.00,'un','Calça jeans slim fit'),(7,333333,'Vestido','Marca Z',100,10,200,'Roupas',300,150.00,200.00,'un','Vestido casual de algodão'),(8,444444,'Arroz','Marca A',500,100,1000,'Alimentos',1000,5.00,10.00,'kg','Arroz tipo 1'),(9,555555,'Feijão','Marca B',400,100,800,'Alimentos',1000,6.00,12.00,'kg','Feijão carioca'),(10,666666,'Macarrão','Marca C',300,50,600,'Alimentos',500,4.00,8.00,'kg','Macarrão tipo espaguete'),(11,777777,'Bolsa','Marca D',150,10,300,'Acessórios',800,100.00,200.00,'un','Bolsa de couro'),(12,888888,'Óculos de Sol','Marca E',100,5,200,'Acessórios',200,50.00,100.00,'un','Óculos de sol com proteção UV'),(13,999999,'Relógio','Marca F',199,20,400,'Acessórios',150,150.00,300.00,'un','Relógio de pulso analógico'),(14,123456,'Smartphone','Samsung',50,5,100,'Eletrônicos',300,800.00,1200.00,'un','Smartphone de última geração'),(15,789012,'Notebook','Dell',30,5,50,'Eletrônicos',2500,2000.00,3000.00,'un','Notebook para trabalho e estudo'),(16,345678,'Smart TV','LG',20,5,30,'Eletrônicos',12000,1500.00,2500.00,'un','Smart TV 4K com sistema operacional WebOS'),(17,901234,'Fone de Ouvido Bluetooth','Sony',100,10,200,'Eletrônicos',300,150.00,250.00,'un','Fone de ouvido sem fio com cancelamento de ruído'),(18,111111,'Camiseta','Marca X',200,20,500,'Roupas',200,30.00,60.00,'un','Camiseta casual de algodão'),(19,222222,'Calça Jeans','Marca Y',150,30,300,'Roupas',500,80.00,120.00,'un','Calça jeans slim fit'),(20,333333,'Vestido','Marca Z',100,10,200,'Roupas',300,150.00,200.00,'un','Vestido casual de algodão'),(21,444444,'Arroz','Marca A',500,100,1000,'Alimentos',1000,5.00,10.00,'kg','Arroz tipo 1'),(22,555555,'Feijão','Marca B',400,100,800,'Alimentos',1000,6.00,12.00,'kg','Feijão carioca'),(23,666666,'Macarrão','Marca C',300,50,600,'Alimentos',500,4.00,8.00,'kg','Macarrão tipo espaguete'),(24,777777,'Bolsa','Marca D',150,10,300,'Acessórios',800,100.00,200.00,'un','Bolsa de couro'),(25,888888,'Óculos de Sol','Marca E',100,5,200,'Acessórios',200,50.00,100.00,'un','Óculos de sol com proteção UV'),(26,999999,'Relógio','Marca F',199,20,400,'Acessórios',150,150.00,300.00,'un','Relógio de pulso analógico');
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_produto` AFTER INSERT ON `produto` FOR EACH ROW BEGIN
    INSERT INTO log_produto (acao, codigo, nome, fabricante, estoque, categoria)
    VALUES ('INSERÇÃO', NEW.codigo, NEW.nome, NEW.fabricante, NEW.estoque, NEW.categoria);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_atualizacao_produto` AFTER UPDATE ON `produto` FOR EACH ROW BEGIN
    INSERT INTO log_produto (acao, codigo, nome, fabricante, estoque, categoria)
    VALUES ('ATUALIZAÇÃO', NEW.codigo, NEW.nome, NEW.fabricante, NEW.estoque, NEW.categoria);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_exclusao_produto` AFTER DELETE ON `produto` FOR EACH ROW BEGIN
    INSERT INTO log_produto (acao, codigo, nome, fabricante, estoque, categoria)
    VALUES ('EXCLUSÃO', OLD.codigo, OLD.nome, OLD.fabricante, OLD.estoque, OLD.categoria);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `top10_produtos_vendidos`
--

DROP TABLE IF EXISTS `top10_produtos_vendidos`;
/*!50001 DROP VIEW IF EXISTS `top10_produtos_vendidos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `top10_produtos_vendidos` AS SELECT 
 1 AS `produto`,
 1 AS `total_vendido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `top_produtos_vendidos`
--

DROP TABLE IF EXISTS `top_produtos_vendidos`;
/*!50001 DROP VIEW IF EXISTS `top_produtos_vendidos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `top_produtos_vendidos` AS SELECT 
 1 AS `produto`,
 1 AS `total_vendido`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `perfil` varchar(10) NOT NULL DEFAULT 'PADRÃO',
  `salario` decimal(10,2) DEFAULT NULL,
  `telefone` varchar(14) DEFAULT NULL,
  `celular` varchar(14) DEFAULT NULL,
  `endereco` text,
  `ultimo_login` datetime DEFAULT '0001-01-01 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (11,'Christian','Coroa','12345','PADRAO',1000.00,'71 999999999','71 999999999','24970-173','2024-06-07 03:50:43'),(12,'Taylor Oliveira de Souza','TaylorSz','tos200689','ADMIN',1500.00,'71 997047379','71 997047379','42801861','2024-06-07 06:11:57');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_usuario` AFTER INSERT ON `usuario` FOR EACH ROW BEGIN
    INSERT INTO log_usuario (acao, nome, usuario, perfil)
    VALUES ('INSERÇÃO', NEW.nome, NEW.usuario, NEW.perfil);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_atualizacao_usuario` AFTER UPDATE ON `usuario` FOR EACH ROW BEGIN
    INSERT INTO log_usuario (acao, nome, usuario, perfil)
    VALUES ('ATUALIZAÇÃO', NEW.nome, NEW.usuario, NEW.perfil);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_exclusao_usuario` AFTER DELETE ON `usuario` FOR EACH ROW BEGIN
    INSERT INTO log_usuario (acao, nome, usuario, perfil)
    VALUES ('EXCLUSÃO', OLD.nome, OLD.usuario, OLD.perfil);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `venda`
--

DROP TABLE IF EXISTS `venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `produto` varchar(255) DEFAULT NULL,
  `quantidade` int DEFAULT NULL,
  `valor_pago` decimal(10,2) DEFAULT NULL,
  `pagamento` varchar(255) DEFAULT NULL,
  `data_venda` date DEFAULT NULL,
  `lucro` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venda`
--

LOCK TABLES `venda` WRITE;
/*!40000 ALTER TABLE `venda` DISABLE KEYS */;
INSERT INTO `venda` VALUES (1,'Smartphone',5,5000.00,'Cartão de Crédito','2024-05-01',NULL),(2,'Camiseta',10,400.00,'Pix','2024-05-03',NULL),(3,'Arroz',20,200.00,'Dinheiro','2024-05-05',NULL),(4,'Notebook',3,7500.00,'Pix','2024-05-06',NULL),(5,'Fone de Ouvido Bluetooth',15,2250.00,'Cartão de Débito','2024-05-09',NULL),(6,'Óculos de Sol',8,720.00,'Dinheiro','2024-05-11',NULL),(7,'Vestido',4,800.00,'Cartão de Crédito','2024-05-12',NULL),(8,'Macarrão',30,240.00,'Pix','2024-05-15',NULL),(9,'Relógio',2,600.00,'Pix','2024-05-17',NULL),(10,'Feijão',15,180.00,'Cartão de Crédito','2024-05-18',NULL),(11,'Smartphone',5,5000.00,'Cartão de Crédito','2024-05-01',NULL),(12,'Camiseta',10,400.00,'Pix','2024-05-03',NULL),(13,'Arroz',20,200.00,'Dinheiro','2024-05-05',NULL),(14,'Notebook',3,7500.00,'Pix','2024-05-06',NULL),(15,'Fone de Ouvido Bluetooth',15,2250.00,'Cartão de Débito','2024-05-09',NULL),(16,'Óculos de Sol',8,720.00,'Dinheiro','2024-05-11',NULL),(17,'Vestido',4,800.00,'Cartão de Crédito','2024-05-12',NULL),(18,'Macarrão',30,240.00,'Pix','2024-05-15',NULL),(19,'Relógio',2,600.00,'Pix','2024-05-17',NULL),(20,'Feijão',15,180.00,'Cartão de Crédito','2024-05-18',NULL),(21,'Smartphone A24',5,1000.00,'Pix','2024-05-01',NULL);
/*!40000 ALTER TABLE `venda` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_venda` AFTER INSERT ON `venda` FOR EACH ROW BEGIN
    INSERT INTO log_venda (acao, produto, quantidade, valor_pago, pagamento, data_venda)
    VALUES ('INSERÇÃO', NEW.produto, NEW.quantidade, NEW.valor_pago, NEW.pagamento, NEW.data_venda);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_atualizacao_venda` AFTER UPDATE ON `venda` FOR EACH ROW BEGIN
    INSERT INTO log_venda (acao, produto, quantidade, valor_pago, pagamento, data_venda)
    VALUES ('ATUALIZAÇÃO', NEW.produto, NEW.quantidade, NEW.valor_pago, NEW.pagamento, NEW.data_venda);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`Taylor`@`localhost`*/ /*!50003 TRIGGER `log_exclusao_venda` AFTER DELETE ON `venda` FOR EACH ROW BEGIN
    INSERT INTO log_venda (acao, produto, quantidade, valor_pago, pagamento, data_venda)
    VALUES ('EXCLUSÃO', OLD.produto, OLD.quantidade, OLD.valor_pago, OLD.pagamento, OLD.data_venda);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Dumping events for database 'sgve'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `reset_total_vendas_diario` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`Taylor`@`localhost`*/ /*!50106 EVENT `reset_total_vendas_diario` ON SCHEDULE EVERY 1 DAY STARTS '2024-06-07 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    SET @total_vendas = 0;
    -- Recalcular o valor das vendas do novo dia
    SET @total_vendas = (SELECT IFNULL(SUM(valor_pago), 0) FROM venda WHERE DATE(data_venda) = CURDATE());
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'sgve'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_add_funcionario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_add_funcionario`(
vnome varchar(100),
vusuario varchar(100),
vsenha varchar(100),
vperfil varchar(10),
vsalario decimal(10,2),
vtelefone varchar(14),
vcelular varchar(14),
vendereco text)
BEGIN
INSERT INTO usuario (nome, usuario, senha, perfil, salario, telefone, celular, endereco)
VALUES (vnome, vusuario, vsenha, vperfil, vsalario, vtelefone, vcelular, vendereco);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_add_produto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_add_produto`(
 vcodigo int, 
 vnome varchar(255), 
 vfabricante varchar(255),
 vestoque int, 
 vestoque_minimo int,
 vestoque_maximo int, 
 vcategoria varchar(100),
 vpeso float, 
 vpreco_compra decimal(10,2), 
 vpreco_venda decimal(10,2),
 vunidade_medida varchar(50), 
 vdescricao text)
BEGIN
insert into produto (codigo,nome,fabricante,estoque,estoque_minimo,estoque_maximo,categoria,peso,preco_compra,preco_venda,unidade_medida,descricao)
values(vcodigo,vnome,vfabricante,vestoque,vestoque_minimo,vestoque_maximo,vcategoria,vpeso,vpreco_compra,vpreco_venda,vunidade_medida,vdescricao);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_add_venda` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_add_venda`(
    vproduto VARCHAR(255),
    vquantidade INT,
    vvalor_pago DECIMAL(10,2),
    vpagamento VARCHAR(255))
BEGIN
    INSERT INTO venda (produto, quantidade, valor_pago, pagamento, data_venda)
    VALUES (vproduto, vquantidade, vvalor_pago, vpagamento, NOW()); -- Utilizando a função NOW() para capturar a data e hora atuais
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_atualizar_funcionario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_atualizar_funcionario`(
p_id int,
p_nome varchar(100),
p_usuario varchar(100),
p_senha varchar(100),
p_perfil varchar(10),
p_salario decimal(10,2),
p_telefone varchar(14),
p_celular varchar(14),
p_endereco text
)
BEGIN
update usuario set
id = p_id ,
nome = p_nome,
usuario = p_usuario,
senha = p_senha,
perfil = p_perfil,
salario = p_salario,
telefone = p_telefone,
celular = p_celular,
endereco = p_endereco
where id = p_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_atualizar_produto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_atualizar_produto`(
    p_id INT,
    p_codigo INT, 
    p_nome VARCHAR(255), 
    p_fabricante VARCHAR(255),
    p_estoque INT, 
    p_estoque_minimo INT,
    p_estoque_maximo INT, 
    p_categoria VARCHAR(100),
    p_peso FLOAT, 
    p_preco_compra DECIMAL(10,2), 
    p_preco_venda DECIMAL(10,2),
    p_unidade_medida VARCHAR(50), 
    p_descricao TEXT
)
BEGIN
    UPDATE produto 
    SET 
        codigo = p_codigo, 
        nome = p_nome, 
        fabricante = p_fabricante, 
        estoque = p_estoque, 
        estoque_minimo = p_estoque_minimo, 
        estoque_maximo = p_estoque_maximo,
        categoria = p_categoria, 
        peso = p_peso, 
        preco_compra = p_preco_compra, 
        preco_venda = p_preco_venda, 
        unidade_medida = p_unidade_medida, 
        descricao = p_descricao
    WHERE id = p_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_atualizar_usuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_atualizar_usuario`(
p_id int,
p_nome varchar(100),
p_usuario varchar(100),
p_senha varchar(100),
p_perfil varchar(10),
p_salario decimal(10,2),
p_telefone varchar(14),
p_celular varchar(14),
p_endereco text
)
BEGIN
update usuario set
id = p_id ,
nome = p_nome,
usuario = p_usuario,
senha = p_senha,
perfil = p_perfil,
salario = p_salario,
telefone = p_telefone,
celular = p_celular,
endereco = p_endereco
where id = p_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_deletar_funcionario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_deletar_funcionario`(vid int)
BEGIN
delete from usuario 
where id = vid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_deletar_produto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_deletar_produto`(vid int)
BEGIN
delete from produto
where id = vid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_deletar_usuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_deletar_usuario`(vid int)
BEGIN
delete from usuario 
where id = vid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_deletar_venda` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`Taylor`@`localhost` PROCEDURE `sp_deletar_venda`(vid int)
BEGIN
delete from venda
where id = vid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `top10_produtos_vendidos`
--

/*!50001 DROP VIEW IF EXISTS `top10_produtos_vendidos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`Taylor`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `top10_produtos_vendidos` AS select `venda`.`produto` AS `produto`,sum(`venda`.`quantidade`) AS `total_vendido` from `venda` group by `venda`.`produto` order by `total_vendido` desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `top_produtos_vendidos`
--

/*!50001 DROP VIEW IF EXISTS `top_produtos_vendidos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`Taylor`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `top_produtos_vendidos` AS select `venda`.`produto` AS `produto`,sum(`venda`.`quantidade`) AS `total_vendido` from `venda` group by `venda`.`produto` order by `total_vendido` desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-07  6:15:36
