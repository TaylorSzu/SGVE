package dao;

import entidades.Produto;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ProdutoDAO {
    
    private Connection conn;
    private PreparedStatement pstm;
    private ResultSet rs;
    
    public void cadastrarProduto(Produto produto){
        String sql = "INSERT INTO produto (codigo, nome, fabricante, estoque, categoria, peso, preco_compra, preco_venda, unidade_medida, descricao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        conn = new ConexaoMySql().obterConexao();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setLong(1, produto.getCodigo());
            pstm.setString(2, produto.getNome());
            pstm.setString(3, produto.getFabricante());
            pstm.setInt(4, produto.getEstoque());
            pstm.setString(5, produto.getCategoria());
            pstm.setFloat(6, produto.getPeso());
            pstm.setBigDecimal(7, produto.getPrecoCompra());
            pstm.setBigDecimal(8, produto.getPrecoVenda());
            pstm.setString(9, produto.getUnidadeMedida());
            pstm.setString(10, produto.getDescricao());
            
            pstm.execute();
            pstm.close();
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "" + erro.getMessage());
        }
    }
    
    public List<Produto> listarProduto(){
        String sql = "SELECT * FROM produto";
        List<Produto> produtos = new ArrayList<>();
        
        conn = new ConexaoMySql().obterConexao();
        
        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()){
                Long id = rs.getLong("id");
                Long codigo = rs.getLong("codigo");
                String nome = rs.getString("nome");
                String fabricante = rs.getString("fabricante");
                int estoque = rs.getInt("estoque");
                String categoria = rs.getString("categoria");
                float peso = rs.getFloat("peso");
                BigDecimal preco_compra = rs.getBigDecimal("preco_compra");
                BigDecimal preco_venda = rs.getBigDecimal("preco_venda");
                String unidadeMedida = rs.getString("unidade_medida");
                String descricao = rs.getString("descricao");
                
                Produto produto = new Produto(id, codigo, nome, fabricante, categoria, 0, unidadeMedida, preco_compra, preco_venda, estoque, descricao);
                produto.setId(id);
                produtos.add(produto);
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao listar produtos: " + erro.getMessage());
        }finally {
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao fechar recursos: " + e.getMessage());
            }
        }
        return produtos;
    }
    
    public void atualizarProduto(Produto produto) {
        String sql = "UPDATE produto SET codigo=?, nome=?, fabricante=?, categoria=?, peso=?, preco_compra=?, preco_venda=?, unidade_medida=?, descricao=? WHERE id=?";
        conn = new ConexaoMySql().obterConexao();

        try {
            if (produto.getId() != null) {
                pstm = conn.prepareStatement(sql);
                pstm.setLong(1, produto.getCodigo());
                pstm.setString(2, produto.getNome());
                pstm.setString(3, produto.getFabricante());
                pstm.setString(4, produto.getCategoria());
                pstm.setFloat(5, produto.getPeso());
                pstm.setBigDecimal(6, produto.getPrecoCompra());
                pstm.setBigDecimal(7, produto.getPrecoVenda());
                pstm.setString(8, produto.getUnidadeMedida());
                pstm.setString(9, produto.getDescricao());
                pstm.setLong(10, produto.getId());

                int linhasAfetadas = pstm.executeUpdate();
                if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Produto atualizado com sucesso.");
                } else {
                    JOptionPane.showMessageDialog(null, "Nenhum produto encontrado com o ID especificado.");
                }
            } else {
            JOptionPane.showMessageDialog(null, "ID do produto não pode ser nulo.");
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar produto: " + erro.getMessage());
        } finally {
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao fechar recursos: " + e.getMessage());
            }
        }
    }    

    public void deletarProduto(Produto produto){
        String sql = "DELETE FROM produto WHERE id = ?";
        conn = new ConexaoMySql().obterConexao();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setLong(1, produto.getId());

            int linhasAfetadas = pstm.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Produto excluído com sucesso.");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum produto encontrado com o ID especificado.");
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar produto: " + erro.getMessage());
        } finally {
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao fechar recursos: " + e.getMessage());
            }
        }
    }
}
