/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entidades.Venda;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno SENAI
 */
public class VendaDAO {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    
    public void registrarVenda(Venda venda){
        String sql = "INSERT INTO venda (produto, quantidade, valor_pago, pagamento) VALUES (?, ?, ?, ?)";
        conn = new ConexaoMySql().obterConexao();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, venda.getProduto());
            pstm.setLong(2, venda.getQuantidade());
            pstm.setBigDecimal(3, venda.getValorPago());
            pstm.setString(4, venda.getPagamento());
            
            pstm.execute();
            pstm.close();
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "" + erro.getMessage());
        }
    }
}
