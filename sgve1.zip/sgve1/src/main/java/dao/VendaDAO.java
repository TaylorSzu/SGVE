package dao;

import entidades.Produto;
import entidades.Venda;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class VendaDAO {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    
    public void registrarVenda(Venda venda){
        String sql = "INSERT INTO venda (produto, quantidade, valor_pago, pagamento) VALUES (?, ?, ?, ?)";
        conn = new ConexaoMySql().obterConexao();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, venda.getProduto());
            pstm.setInt(2, venda.getQuantidade());
            pstm.setBigDecimal(3, venda.getValorPago());
            pstm.setString(4, venda.getPagamento());
            
            pstm.execute();
            pstm.close();
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "" + erro.getMessage());
        }
    }
    
    public List<Venda> HistoricoVenda(){
        String sql = "SELECT * FROM venda";
        List<Venda> vendas = new ArrayList<>();
        conn = new ConexaoMySql().obterConexao();
        
        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()){
                Long id = rs.getLong("id");
                String produto = rs.getString("produto");
                int quantidade = rs.getInt("quantidade");
                BigDecimal valorPago = rs.getBigDecimal("valor_pago");
                String pagamento = rs.getString("pagamento");
                
                Venda venda = new Venda(produto, quantidade, valorPago, pagamento);
                venda.setId(id);
                
                vendas.add(venda);
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao listar vendas: " + erro.getMessage());
        }finally {
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao fechar recursos: " + e.getMessage());
            }
        }
        return vendas;
    }
    
    public void deletarVenda(Venda venda){
        String sql = "DELETE FROM venda WHERE id = ?";
        conn = new ConexaoMySql().obterConexao();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setLong(1, venda.getId());

            int linhasAfetadas = pstm.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Venda excluída com sucesso.");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma venda encontrada com o ID especificado.");
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar venda: " + erro.getMessage());
        } finally {
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao fechar recursos: " + e.getMessage());
            }
        }
    }
}
