package view;

import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import controller.CategoriaController;
import controller.DashboardController;
import controller.EstoqueController;
import controller.ProdutoController;
import controller.VendaController;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Dashboard extends javax.swing.JFrame {

    private DashboardController dashboardController;
    private CategoriaController categoriaController;
    private ProdutoController produtoController;
    private EstoqueController estoqueController;
    private VendaController vendaController;
    
    public Dashboard() {
        initComponents();
        this.dashboardController = new DashboardController(this);
        this.categoriaController = new CategoriaController(this);
        this.produtoController = new ProdutoController(this);
        this.estoqueController = new EstoqueController(this);
        this.vendaController = new VendaController(this);
        dashboardController.inserirIcone(this);
        setLocationRelativeTo(null);
        eventosDashboard();
        eventosCategoria();
        eventosProduto();
        eventosEstoque();
        eventosVenda();
    }
    
    private void eventosDashboard(){
        RegistrarVenda.addActionListener(dashboardController);
        HistoricoVendas.addActionListener(dashboardController);
        AdicionarProduto.addActionListener(dashboardController);
        ListaProduto.addActionListener(dashboardController);
        ControleEstoque.addActionListener(dashboardController);
    }
    
    private void eventosProduto(){
        btnCadastrarProduto.addActionListener(produtoController);
        btnDetalheProduto.addActionListener(produtoController);
        btnEditarProduto.addActionListener(produtoController);
        btnExcluirProduto.addActionListener(produtoController);
        btnSalvarProdutoEditar.addActionListener(produtoController);
        tabelaListaProduto.addMouseListener(produtoController);
    }
    
    private void eventosEstoque(){
        tabelaControleEstoque.addMouseListener(estoqueController);
    }
    
    private void eventosVenda(){
        btnVenderVenda.addActionListener(vendaController);
        
    }
    
    private void eventosCategoria(){
        btnSalvarCategoria.addActionListener(categoriaController);
        btnCancelarCategoria.addActionListener(categoriaController);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        telaCategoria = new javax.swing.JDialog();
        jLabel34 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        txtNomeCategoria = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        btnCancelarCategoria = new javax.swing.JButton();
        btnSalvarCategoria = new javax.swing.JButton();
        telaEditarProduto = new javax.swing.JDialog();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        txtNomeProdutoEditar = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        txtFabricanteProdutoEditar = new javax.swing.JTextField();
        txtCodigoProdutoEditar = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        comboBoxCategoriaEditar = new javax.swing.JComboBox<>();
        jLabel43 = new javax.swing.JLabel();
        txtPesoProdutoEditar = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        txtUnidadeMedidaProdutoEditar = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        txtPrecoCompraProdutoEditar = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        txtPrecoVendaProdutoEditar = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDescricaoProdutoEditar = new javax.swing.JTextArea();
        btnCancelarEditar = new javax.swing.JButton();
        btnSalvarProdutoEditar = new javax.swing.JButton();
        telaDetalheProduto = new javax.swing.JDialog();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        txtNomeProdutoDetalhe = new javax.swing.JTextField();
        jLabel52 = new javax.swing.JLabel();
        txtFabricanteProdutoDetalhe = new javax.swing.JTextField();
        txtCodigoProdutoDetalhe = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        txtPesoProdutoDetalhe = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        txtUnidadeMedidaProdutoDetalhe = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        txtPrecoCompraProdutoDetalhe = new javax.swing.JTextField();
        jLabel58 = new javax.swing.JLabel();
        txtPrecoVendaProdutoDetalhe = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        txtEstoqueProdutoDetalhe = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtDescricaoProdutoDetalhe = new javax.swing.JTextArea();
        txtCategoriaProdutoDetalhe = new javax.swing.JTextField();
        painelPrincipal = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        painelRegistrarVenda = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        panel1 = new view.panel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabelaRegistrarVenda = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        txtPesquisarProdutoVenda = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtProdutoVenda = new javax.swing.JTextField();
        panel3 = new view.panel();
        jLabel10 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        spinnerQuantidadeVenda = new javax.swing.JSpinner();
        txtValorPagoVenda = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        comboBoxPagamento = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btnVenderVenda = new javax.swing.JButton();
        painelListaProduto = new javax.swing.JPanel();
        btnExcluirProduto = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabelaListaProduto = new javax.swing.JTable();
        btnDetalheProduto = new javax.swing.JButton();
        btnEditarProduto = new javax.swing.JButton();
        painelHistoricoVendas = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tabelaHistoricoVendas = new javax.swing.JTable();
        btnEditarVenda = new javax.swing.JButton();
        painelControleEstoque = new javax.swing.JPanel();
        panel4 = new view.panel();
        txtPesquisaProdutoEstoque = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaControleEstoque = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        txtProdutoEstoque = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        spinnerQuantidadeEstoque = new javax.swing.JSpinner();
        spinnerMinimoEstoque = new javax.swing.JSpinner();
        spinnerMaximoEstoque = new javax.swing.JSpinner();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        painelRegistrarProduto = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        panel2 = new view.panel();
        txtNomeProduto = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtFabricanteProduto = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtCodigoProduto = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        ComboBoxCategoria = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        txtPesoProduto = new javax.swing.JTextField();
        txtUnidadeMedidaProduto = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        txtPrecoCompraProduto = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txtPrecoVendaProduto = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        btnCategoria = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtDescricaoProduto = new javax.swing.JTextArea();
        jLabel21 = new javax.swing.JLabel();
        btnCadastrarProduto = new javax.swing.JButton();
        btnCancelarProduto = new javax.swing.JButton();
        txtEstoqueProduto = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jMenuBar2 = new javax.swing.JMenuBar();
        Venda = new javax.swing.JMenu();
        RegistrarVenda = new javax.swing.JMenuItem();
        HistoricoVendas = new javax.swing.JMenuItem();
        RelatorioVendas = new javax.swing.JMenuItem();
        Estoque = new javax.swing.JMenu();
        AdicionarProduto = new javax.swing.JMenuItem();
        ListaProduto = new javax.swing.JMenuItem();
        ControleEstoque = new javax.swing.JMenuItem();
        Financeiro = new javax.swing.JMenu();
        Configurações = new javax.swing.JMenu();
        Tema = new javax.swing.JMenu();
        ModoClaro = new javax.swing.JMenuItem();
        ModoEscuro = new javax.swing.JMenuItem();
        Ajuda = new javax.swing.JMenu();

        telaCategoria.setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        telaCategoria.setMinimumSize(new java.awt.Dimension(720, 280));
        telaCategoria.setUndecorated(true);

        jLabel34.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("NOVA CATEGORIA");

        jTextField4.setEditable(false);
        jTextField4.setText("0");

        jLabel35.setText("Id");

        jLabel36.setText("Nome");

        btnCancelarCategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/cancelar.png"))); // NOI18N
        btnCancelarCategoria.setText("Cancelar");
        btnCancelarCategoria.setPreferredSize(new java.awt.Dimension(115, 45));

        btnSalvarCategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/salve-.png"))); // NOI18N
        btnSalvarCategoria.setText("Salvar");
        btnSalvarCategoria.setPreferredSize(new java.awt.Dimension(99, 45));

        javax.swing.GroupLayout telaCategoriaLayout = new javax.swing.GroupLayout(telaCategoria.getContentPane());
        telaCategoria.getContentPane().setLayout(telaCategoriaLayout);
        telaCategoriaLayout.setHorizontalGroup(
            telaCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(telaCategoriaLayout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(telaCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel36)
                    .addComponent(jLabel35)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNomeCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(68, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaCategoriaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSalvarCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnCancelarCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );
        telaCategoriaLayout.setVerticalGroup(
            telaCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(telaCategoriaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNomeCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(telaCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvarCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelarCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel38.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("EDITAR PRODUTO");

        jLabel39.setText("Nome");

        jLabel40.setText("Fabricante");

        jLabel41.setText("Codigo");

        jLabel42.setText("Categoria");

        jLabel43.setText("Peso");

        jLabel44.setText("Unidade de Medida");

        txtUnidadeMedidaProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUnidadeMedidaProdutoEditarActionPerformed(evt);
            }
        });

        jLabel45.setText("Preço de Compra");

        txtPrecoCompraProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoCompraProdutoEditarActionPerformed(evt);
            }
        });

        jLabel46.setText("Preço de Venda");

        txtPrecoVendaProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoVendaProdutoEditarActionPerformed(evt);
            }
        });

        jLabel48.setText("Descrição");

        txtDescricaoProdutoEditar.setColumns(20);
        txtDescricaoProdutoEditar.setRows(5);
        jScrollPane2.setViewportView(txtDescricaoProdutoEditar);

        btnCancelarEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/cancelar.png"))); // NOI18N
        btnCancelarEditar.setText("Cancelar");
        btnCancelarEditar.setPreferredSize(new java.awt.Dimension(77, 45));
        btnCancelarEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarEditarActionPerformed(evt);
            }
        });

        btnSalvarProdutoEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/salve-.png"))); // NOI18N
        btnSalvarProdutoEditar.setText("Salvar");
        btnSalvarProdutoEditar.setPreferredSize(new java.awt.Dimension(77, 45));
        btnSalvarProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarProdutoEditarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout telaEditarProdutoLayout = new javax.swing.GroupLayout(telaEditarProduto.getContentPane());
        telaEditarProduto.getContentPane().setLayout(telaEditarProdutoLayout);
        telaEditarProdutoLayout.setHorizontalGroup(
            telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNomeProdutoEditar))
                    .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel40)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtFabricanteProdutoEditar))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel41)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCodigoProdutoEditar))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel42)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comboBoxCategoriaEditar, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel43)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPesoProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel44)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtUnidadeMedidaProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel45)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecoCompraProdutoEditar, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel46)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecoVendaProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(286, 286, 286))
                    .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel48)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaEditarProdutoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnSalvarProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelarEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        telaEditarProdutoLayout.setVerticalGroup(
            telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCodigoProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41))
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39))
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFabricanteProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel40))
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxCategoriaEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel42)
                    .addComponent(jLabel43)
                    .addComponent(txtPesoProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel44)
                    .addComponent(txtUnidadeMedidaProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(txtPrecoCompraProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrecoVendaProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel46))
                .addGap(18, 18, 18)
                .addComponent(jLabel48)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancelarEditar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalvarProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(0, 16, Short.MAX_VALUE))
        );

        jLabel50.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel50.setText("DETALHES DO PRODUTO");

        jLabel51.setText("Nome");

        txtNomeProdutoDetalhe.setEditable(false);

        jLabel52.setText("Fabricante");

        txtFabricanteProdutoDetalhe.setEditable(false);

        txtCodigoProdutoDetalhe.setEditable(false);

        jLabel53.setText("Codigo");

        jLabel54.setText("Categoria");

        jLabel55.setText("Peso");

        txtPesoProdutoDetalhe.setEditable(false);
        txtPesoProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel56.setText("Unidade de Medida");

        txtUnidadeMedidaProdutoDetalhe.setEditable(false);
        txtUnidadeMedidaProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUnidadeMedidaProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel57.setText("Preço de Compra");

        txtPrecoCompraProdutoDetalhe.setEditable(false);
        txtPrecoCompraProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoCompraProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel58.setText("Preço de Venda");

        txtPrecoVendaProdutoDetalhe.setEditable(false);
        txtPrecoVendaProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoVendaProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel59.setText("Estoque");

        txtEstoqueProdutoDetalhe.setEditable(false);
        txtEstoqueProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstoqueProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel60.setText("Descrição");

        txtDescricaoProdutoDetalhe.setEditable(false);
        txtDescricaoProdutoDetalhe.setColumns(20);
        txtDescricaoProdutoDetalhe.setRows(5);
        jScrollPane4.setViewportView(txtDescricaoProdutoDetalhe);

        txtCategoriaProdutoDetalhe.setEditable(false);
        txtCategoriaProdutoDetalhe.setPreferredSize(new java.awt.Dimension(63, 30));

        javax.swing.GroupLayout telaDetalheProdutoLayout = new javax.swing.GroupLayout(telaDetalheProduto.getContentPane());
        telaDetalheProduto.getContentPane().setLayout(telaDetalheProdutoLayout);
        telaDetalheProdutoLayout.setHorizontalGroup(
            telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel50, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4)
                    .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel51)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNomeProdutoDetalhe))
                    .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel52)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtFabricanteProdutoDetalhe))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel53)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCodigoProdutoDetalhe))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel54)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCategoriaProdutoDetalhe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel55)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPesoProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel56)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtUnidadeMedidaProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel57)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecoCompraProdutoDetalhe, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel58)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecoVendaProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel59)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEstoqueProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel60)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        telaDetalheProdutoLayout.setVerticalGroup(
            telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCodigoProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel53))
                .addGap(18, 18, 18)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel51))
                .addGap(18, 18, 18)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFabricanteProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel52))
                .addGap(18, 18, 18)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel54)
                        .addComponent(jLabel55)
                        .addComponent(txtPesoProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel56)
                        .addComponent(txtUnidadeMedidaProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtCategoriaProdutoDetalhe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel57)
                    .addComponent(txtPrecoCompraProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel59)
                    .addComponent(txtEstoqueProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrecoVendaProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel58))
                .addGap(18, 18, 18)
                .addComponent(jLabel60)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        painelPrincipal.setLayout(new java.awt.CardLayout());

        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel49, javax.swing.GroupLayout.DEFAULT_SIZE, 1412, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel49, javax.swing.GroupLayout.DEFAULT_SIZE, 758, Short.MAX_VALUE)
        );

        painelPrincipal.add(jPanel1, "card4");

        painelRegistrarVenda.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("REGISTRAR VENDA");

        panel1.setBackground(new java.awt.Color(245, 245, 245));
        panel1.setRoundBottomLeft(10);
        panel1.setRoundBottomRight(10);
        panel1.setRoundTopLeft(10);
        panel1.setRoundTopRight(10);

        tabelaRegistrarVenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(tabelaRegistrarVenda);

        jLabel3.setText("Pesquisar Produto");

        jLabel4.setText("Produto");

        panel3.setBackground(new java.awt.Color(204, 204, 204));
        panel3.setRoundBottomLeft(25);
        panel3.setRoundBottomRight(25);
        panel3.setRoundTopLeft(25);
        panel3.setRoundTopRight(25);

        jLabel10.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel10.setText("0");

        jLabel24.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel24.setText("Troco:");

        jLabel25.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel25.setText("Total:");

        jLabel26.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel26.setText("Pago:");

        jLabel27.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel27.setText("0");

        jLabel28.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel28.setText("0");

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 6, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setPreferredSize(new java.awt.Dimension(0, 6));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 6, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel3Layout.createSequentialGroup()
                        .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panel3Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panel3Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jLabel26))
                            .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 109, Short.MAX_VALUE))
                    .addGroup(panel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 354, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );

        jLabel6.setText("Quantidade");

        jLabel7.setText("Valor Pago");

        jRadioButton1.setText("Sim");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        jRadioButton2.setText("Não");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        jLabel8.setText("Venda por Peso?");

        comboBoxPagamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pix", "Debito", "Credito a vista", "Credito parcelado", " " }));

        jLabel9.setText("Forma de pagamento");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/cancelar.png"))); // NOI18N
        jButton1.setText("Cancelar");
        jButton1.setPreferredSize(new java.awt.Dimension(115, 45));

        btnVenderVenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/terminal-pos.png"))); // NOI18N
        btnVenderVenda.setText("Vender");
        btnVenderVenda.setPreferredSize(new java.awt.Dimension(105, 45));

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(comboBoxPagamento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(panel1Layout.createSequentialGroup()
                            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4)
                                .addComponent(jLabel9)
                                .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(333, 333, 333)))
                    .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txtPesquisarProdutoVenda, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 693, Short.MAX_VALUE)
                        .addComponent(txtProdutoVenda, javax.swing.GroupLayout.Alignment.LEADING))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel6))
                            .addComponent(spinnerQuantidadeVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtValorPagoVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(27, 27, 27)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panel1Layout.createSequentialGroup()
                                .addComponent(jRadioButton1)
                                .addGap(18, 18, 18)
                                .addComponent(jRadioButton2))
                            .addComponent(jLabel8))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnVenderVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPesquisarProdutoVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtProdutoVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtValorPagoVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(spinnerQuantidadeVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jRadioButton1)
                            .addComponent(jRadioButton2))
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panel1Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(comboBoxPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                                .addGap(156, 156, 156)
                                .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(18, 18, 18)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnVenderVenda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout painelRegistrarVendaLayout = new javax.swing.GroupLayout(painelRegistrarVenda);
        painelRegistrarVenda.setLayout(painelRegistrarVendaLayout);
        painelRegistrarVendaLayout.setHorizontalGroup(
            painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1394, Short.MAX_VALUE)
            .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        painelRegistrarVendaLayout.setVerticalGroup(
            painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        painelPrincipal.add(painelRegistrarVenda, "card2");

        btnExcluirProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/excluir.png"))); // NOI18N
        btnExcluirProduto.setText("Excluir");
        btnExcluirProduto.setPreferredSize(new java.awt.Dimension(83, 45));
        btnExcluirProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirProdutoActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("LISTA DE PRODUTO");

        tabelaListaProduto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(tabelaListaProduto);

        btnDetalheProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/pesquisa.png"))); // NOI18N
        btnDetalheProduto.setText("Detalhes");
        btnDetalheProduto.setPreferredSize(new java.awt.Dimension(83, 45));
        btnDetalheProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetalheProdutoActionPerformed(evt);
            }
        });

        btnEditarProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/editar-informacao.png"))); // NOI18N
        btnEditarProduto.setText("Editar");
        btnEditarProduto.setPreferredSize(new java.awt.Dimension(83, 45));
        btnEditarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarProdutoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelListaProdutoLayout = new javax.swing.GroupLayout(painelListaProduto);
        painelListaProduto.setLayout(painelListaProdutoLayout);
        painelListaProdutoLayout.setHorizontalGroup(
            painelListaProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 1412, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelListaProdutoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnDetalheProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnEditarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnExcluirProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
            .addGroup(painelListaProdutoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 1388, Short.MAX_VALUE)
                .addContainerGap())
        );
        painelListaProdutoLayout.setVerticalGroup(
            painelListaProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelListaProdutoLayout.createSequentialGroup()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 582, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(painelListaProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDetalheProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEditarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluirProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        painelPrincipal.add(painelListaProduto, "card3");

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/excluir.png"))); // NOI18N
        jButton10.setText("Excluir");
        jButton10.setPreferredSize(new java.awt.Dimension(83, 45));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("HISTORICO DE VENDAS");

        tabelaHistoricoVendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane7.setViewportView(tabelaHistoricoVendas);

        btnEditarVenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/editar-informacao.png"))); // NOI18N
        btnEditarVenda.setText("Editar");
        btnEditarVenda.setPreferredSize(new java.awt.Dimension(83, 45));
        btnEditarVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarVendaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelHistoricoVendasLayout = new javax.swing.GroupLayout(painelHistoricoVendas);
        painelHistoricoVendas.setLayout(painelHistoricoVendasLayout);
        painelHistoricoVendasLayout.setHorizontalGroup(
            painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, 1406, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelHistoricoVendasLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnEditarVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
            .addGroup(painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(painelHistoricoVendasLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 1394, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        painelHistoricoVendasLayout.setVerticalGroup(
            painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelHistoricoVendasLayout.createSequentialGroup()
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(632, 632, 632)
                .addGroup(painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEditarVenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelHistoricoVendasLayout.createSequentialGroup()
                    .addContainerGap(92, Short.MAX_VALUE)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(76, 76, 76)))
        );

        painelPrincipal.add(painelHistoricoVendas, "card3");

        painelControleEstoque.setBackground(new java.awt.Color(255, 255, 255));

        panel4.setBackground(new java.awt.Color(245, 245, 245));
        panel4.setRoundBottomLeft(25);
        panel4.setRoundBottomRight(25);
        panel4.setRoundTopLeft(25);
        panel4.setRoundTopRight(25);

        txtPesquisaProdutoEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesquisaProdutoEstoqueActionPerformed(evt);
            }
        });

        tabelaControleEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "CODIGO", "PRODUTO", "ESTOQUE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabelaControleEstoque);

        jLabel2.setText("Pesquisar Produto");

        jLabel30.setText("Produto");

        txtProdutoEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProdutoEstoqueActionPerformed(evt);
            }
        });

        jLabel31.setText("Quantidade");

        spinnerMinimoEstoque.setPreferredSize(new java.awt.Dimension(64, 30));

        jLabel32.setText("Minimo");

        jLabel33.setText("Maximo");

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/cancelar.png"))); // NOI18N
        jButton3.setText("Cancelar");
        jButton3.setPreferredSize(new java.awt.Dimension(115, 45));

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/adicionar.png"))); // NOI18N
        jButton11.setText("Adicionar");
        jButton11.setPreferredSize(new java.awt.Dimension(119, 45));
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel4Layout = new javax.swing.GroupLayout(panel4);
        panel4.setLayout(panel4Layout);
        panel4Layout.setHorizontalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel4Layout.createSequentialGroup()
                        .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPesquisaProdutoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel30)
                            .addComponent(txtProdutoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panel4Layout.createSequentialGroup()
                                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(spinnerQuantidadeEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel31))
                                .addGap(18, 18, 18)
                                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(spinnerMinimoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel32))
                                .addGap(18, 18, 18)
                                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel33)
                                    .addComponent(spinnerMaximoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        panel4Layout.setVerticalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtPesquisaProdutoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtProdutoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jLabel32)
                    .addComponent(jLabel33))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spinnerMaximoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(spinnerMinimoEstoque, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(spinnerQuantidadeEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jLabel29.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("CONTROLE DE ESTOQUE");

        javax.swing.GroupLayout painelControleEstoqueLayout = new javax.swing.GroupLayout(painelControleEstoque);
        painelControleEstoque.setLayout(painelControleEstoqueLayout);
        painelControleEstoqueLayout.setHorizontalGroup(
            painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, 1406, Short.MAX_VALUE)
        );
        painelControleEstoqueLayout.setVerticalGroup(
            painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelControleEstoqueLayout.createSequentialGroup()
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        painelPrincipal.add(painelControleEstoque, "card7");

        painelRegistrarProduto.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("CADASTRAR PRODUTO");

        panel2.setBackground(new java.awt.Color(245, 245, 245));
        panel2.setRoundBottomLeft(10);
        panel2.setRoundBottomRight(10);
        panel2.setRoundTopLeft(10);
        panel2.setRoundTopRight(10);

        txtNomeProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeProdutoActionPerformed(evt);
            }
        });

        jLabel13.setText("Nome do Produto");

        txtFabricanteProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFabricanteProdutoActionPerformed(evt);
            }
        });

        jLabel14.setText("Fabricante");

        txtCodigoProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoProdutoActionPerformed(evt);
            }
        });

        jLabel15.setText("Codigo");

        jLabel16.setText("Categoria");

        ComboBoxCategoria.setEditable(true);

        jLabel17.setText("Peso");

        txtPesoProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoProdutoActionPerformed(evt);
            }
        });

        txtUnidadeMedidaProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUnidadeMedidaProdutoActionPerformed(evt);
            }
        });

        jLabel18.setText("Unidade de medida");

        txtPrecoCompraProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoCompraProdutoActionPerformed(evt);
            }
        });

        jLabel19.setText("Preço de Compra");

        txtPrecoVendaProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoVendaProdutoActionPerformed(evt);
            }
        });

        jLabel20.setText("Preço de Venda");

        btnCategoria.setContentAreaFilled(false);
        btnCategoria.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCategoriaActionPerformed(evt);
            }
        });

        txtDescricaoProduto.setColumns(20);
        txtDescricaoProduto.setRows(5);
        jScrollPane3.setViewportView(txtDescricaoProduto);

        jLabel21.setText("Descrição");

        btnCadastrarProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/registro.png"))); // NOI18N
        btnCadastrarProduto.setText("Cadastrar");
        btnCadastrarProduto.setPreferredSize(new java.awt.Dimension(83, 45));

        btnCancelarProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/cancelar.png"))); // NOI18N
        btnCancelarProduto.setText("Cancelar");
        btnCancelarProduto.setPreferredSize(new java.awt.Dimension(79, 45));
        btnCancelarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarProdutoActionPerformed(evt);
            }
        });

        txtEstoqueProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstoqueProdutoActionPerformed(evt);
            }
        });

        jLabel22.setText("Estoque");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel2Layout.createSequentialGroup()
                            .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(ComboBoxCategoria, javax.swing.GroupLayout.Alignment.LEADING, 0, 236, Short.MAX_VALUE)
                                    .addComponent(txtCodigoProduto, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.LEADING))
                                .addComponent(jLabel16))
                            .addGap(18, 18, 18)
                            .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(panel2Layout.createSequentialGroup()
                                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel13)
                                        .addComponent(txtNomeProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18)
                                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel14)
                                        .addComponent(txtFabricanteProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(panel2Layout.createSequentialGroup()
                                    .addComponent(btnCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtPesoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel17))
                                    .addGap(18, 18, 18)
                                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtUnidadeMedidaProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel18))
                                    .addGap(18, 18, 18)
                                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtPrecoCompraProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel19))
                                    .addGap(18, 18, 18)
                                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtPrecoVendaProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel20))
                                    .addGap(18, 18, 18)
                                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel22)
                                        .addComponent(txtEstoqueProduto))))
                            .addGap(50, 50, 50))
                        .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1252, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panel2Layout.createSequentialGroup()
                                .addGap(994, 994, 994)
                                .addComponent(btnCadastrarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnCancelarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFabricanteProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCodigoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17)
                    .addComponent(jLabel18)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20)
                    .addComponent(jLabel22))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ComboBoxCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtPesoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtUnidadeMedidaProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtPrecoCompraProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtPrecoVendaProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtEstoqueProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCancelarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCadastrarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout painelRegistrarProdutoLayout = new javax.swing.GroupLayout(painelRegistrarProduto);
        painelRegistrarProduto.setLayout(painelRegistrarProdutoLayout);
        painelRegistrarProdutoLayout.setHorizontalGroup(
            painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 1412, Short.MAX_VALUE)
            .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        painelRegistrarProdutoLayout.setVerticalGroup(
            painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        painelPrincipal.add(painelRegistrarProduto, "card8");

        jMenuBar2.setMinimumSize(new java.awt.Dimension(64, 30));
        jMenuBar2.setPreferredSize(new java.awt.Dimension(500, 30));

        Venda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/pos-terminal.png"))); // NOI18N
        Venda.setText("Venda");

        RegistrarVenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/caixa-registradora.png"))); // NOI18N
        RegistrarVenda.setText("Registrar Venda");
        RegistrarVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistrarVendaActionPerformed(evt);
            }
        });
        Venda.add(RegistrarVenda);

        HistoricoVendas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/pedido.png"))); // NOI18N
        HistoricoVendas.setText("Historico de Vendas");
        HistoricoVendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HistoricoVendasActionPerformed(evt);
            }
        });
        Venda.add(HistoricoVendas);

        RelatorioVendas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/recibo.png"))); // NOI18N
        RelatorioVendas.setText("Relatorio de Vendas");
        RelatorioVendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RelatorioVendasActionPerformed(evt);
            }
        });
        Venda.add(RelatorioVendas);

        jMenuBar2.add(Venda);

        Estoque.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/estoque-pronto.png"))); // NOI18N
        Estoque.setText("Estoque");

        AdicionarProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/novo-produto.png"))); // NOI18N
        AdicionarProduto.setText("Adicionar Produto");
        Estoque.add(AdicionarProduto);

        ListaProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/caracteristicas.png"))); // NOI18N
        ListaProduto.setText("Lista de Produtos");
        Estoque.add(ListaProduto);

        ControleEstoque.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/preparar.png"))); // NOI18N
        ControleEstoque.setText("Controle de Estoque");
        Estoque.add(ControleEstoque);

        jMenuBar2.add(Estoque);

        Financeiro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/lucro-financeiro.png"))); // NOI18N
        Financeiro.setText("Financeiro");
        jMenuBar2.add(Financeiro);

        Configurações.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/configuracoes.png"))); // NOI18N
        Configurações.setText("Configurações");

        Tema.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/tema.png"))); // NOI18N
        Tema.setText("Tema");

        ModoClaro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/sol.png"))); // NOI18N
        ModoClaro.setText("Modo Claro");
        ModoClaro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModoClaroActionPerformed(evt);
            }
        });
        Tema.add(ModoClaro);

        ModoEscuro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/lua.png"))); // NOI18N
        ModoEscuro.setText("Modo Escuro");
        ModoEscuro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModoEscuroActionPerformed(evt);
            }
        });
        Tema.add(ModoEscuro);

        Configurações.add(Tema);

        jMenuBar2.add(Configurações);

        Ajuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/ponto-de-informacao.png"))); // NOI18N
        Ajuda.setText("Ajuda");
        jMenuBar2.add(Ajuda);

        setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RelatorioVendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RelatorioVendasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RelatorioVendasActionPerformed

    private void RegistrarVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistrarVendaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RegistrarVendaActionPerformed

    private void txtNomeProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeProdutoActionPerformed

    private void txtFabricanteProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFabricanteProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFabricanteProdutoActionPerformed

    private void txtCodigoProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoProdutoActionPerformed

    private void txtPesoProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoProdutoActionPerformed

    private void txtUnidadeMedidaProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUnidadeMedidaProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUnidadeMedidaProdutoActionPerformed

    private void txtPrecoCompraProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoCompraProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoCompraProdutoActionPerformed

    private void txtPrecoVendaProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoVendaProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoVendaProdutoActionPerformed

    private void txtEstoqueProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEstoqueProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEstoqueProdutoActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void btnExcluirProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnExcluirProdutoActionPerformed

    private void btnDetalheProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetalheProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDetalheProdutoActionPerformed

    private void btnEditarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarProdutoActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void btnEditarVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarVendaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarVendaActionPerformed

    private void HistoricoVendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HistoricoVendasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HistoricoVendasActionPerformed

    private void txtPesquisaProdutoEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisaProdutoEstoqueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesquisaProdutoEstoqueActionPerformed

    private void txtProdutoEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProdutoEstoqueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProdutoEstoqueActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void ModoClaroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModoClaroActionPerformed
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatMacLightLaf());
                SwingUtilities.updateComponentTreeUI(this);
            } catch (UnsupportedLookAndFeelException ex) {
                Logger.getLogger(Dashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }//GEN-LAST:event_ModoClaroActionPerformed

    private void ModoEscuroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModoEscuroActionPerformed
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatMacDarkLaf());
                SwingUtilities.updateComponentTreeUI(this);
            } catch (UnsupportedLookAndFeelException ex) {
                Logger.getLogger(Dashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }//GEN-LAST:event_ModoEscuroActionPerformed

    private void btnCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoriaActionPerformed
        telaCategoria.setLocationRelativeTo(null);
        telaCategoria.setVisible(true);
    }//GEN-LAST:event_btnCategoriaActionPerformed

    private void txtUnidadeMedidaProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUnidadeMedidaProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUnidadeMedidaProdutoEditarActionPerformed

    private void txtPrecoCompraProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoCompraProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoCompraProdutoEditarActionPerformed

    private void txtPrecoVendaProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoVendaProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoVendaProdutoEditarActionPerformed

    private void btnSalvarProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSalvarProdutoEditarActionPerformed

    private void txtUnidadeMedidaProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUnidadeMedidaProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUnidadeMedidaProdutoDetalheActionPerformed

    private void txtPrecoCompraProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoCompraProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoCompraProdutoDetalheActionPerformed

    private void txtPrecoVendaProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoVendaProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoVendaProdutoDetalheActionPerformed

    private void txtPesoProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoProdutoDetalheActionPerformed

    private void txtEstoqueProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEstoqueProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEstoqueProdutoDetalheActionPerformed

    private void btnCancelarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarProdutoActionPerformed

    }//GEN-LAST:event_btnCancelarProdutoActionPerformed

    private void btnCancelarEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarEditarActionPerformed
        getTelaEditarProduto().setVisible(false);
    }//GEN-LAST:event_btnCancelarEditarActionPerformed

    public static void main(String args[]) {
        
        try {
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AdicionarProduto;
    private javax.swing.JMenu Ajuda;
    private javax.swing.JComboBox<String> ComboBoxCategoria;
    private javax.swing.JMenu Configurações;
    private javax.swing.JMenuItem ControleEstoque;
    private javax.swing.JMenu Estoque;
    private javax.swing.JMenu Financeiro;
    private javax.swing.JMenuItem HistoricoVendas;
    private javax.swing.JMenuItem ListaProduto;
    private javax.swing.JMenuItem ModoClaro;
    private javax.swing.JMenuItem ModoEscuro;
    private javax.swing.JMenuItem RegistrarVenda;
    private javax.swing.JMenuItem RelatorioVendas;
    private javax.swing.JMenu Tema;
    private javax.swing.JMenu Venda;
    private javax.swing.JButton btnCadastrarProduto;
    private javax.swing.JButton btnCancelarCategoria;
    private javax.swing.JButton btnCancelarEditar;
    private javax.swing.JButton btnCancelarProduto;
    private javax.swing.JButton btnCategoria;
    private javax.swing.JButton btnDetalheProduto;
    private javax.swing.JButton btnEditarProduto;
    private javax.swing.JButton btnEditarVenda;
    private javax.swing.JButton btnExcluirProduto;
    private javax.swing.JButton btnSalvarCategoria;
    private javax.swing.JButton btnSalvarProdutoEditar;
    private javax.swing.JButton btnVenderVenda;
    private javax.swing.JComboBox<String> comboBoxCategoriaEditar;
    private javax.swing.JComboBox<String> comboBoxPagamento;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JPanel painelControleEstoque;
    private javax.swing.JPanel painelHistoricoVendas;
    private javax.swing.JPanel painelListaProduto;
    private javax.swing.JPanel painelPrincipal;
    private javax.swing.JPanel painelRegistrarProduto;
    private javax.swing.JPanel painelRegistrarVenda;
    private view.panel panel1;
    private view.panel panel2;
    private view.panel panel3;
    private view.panel panel4;
    private javax.swing.JSpinner spinnerMaximoEstoque;
    private javax.swing.JSpinner spinnerMinimoEstoque;
    private javax.swing.JSpinner spinnerQuantidadeEstoque;
    private javax.swing.JSpinner spinnerQuantidadeVenda;
    private javax.swing.JTable tabelaControleEstoque;
    private javax.swing.JTable tabelaHistoricoVendas;
    private javax.swing.JTable tabelaListaProduto;
    private javax.swing.JTable tabelaRegistrarVenda;
    private javax.swing.JDialog telaCategoria;
    private javax.swing.JDialog telaDetalheProduto;
    private javax.swing.JDialog telaEditarProduto;
    private javax.swing.JTextField txtCategoriaProdutoDetalhe;
    private javax.swing.JTextField txtCodigoProduto;
    private javax.swing.JTextField txtCodigoProdutoDetalhe;
    private javax.swing.JTextField txtCodigoProdutoEditar;
    private javax.swing.JTextArea txtDescricaoProduto;
    private javax.swing.JTextArea txtDescricaoProdutoDetalhe;
    private javax.swing.JTextArea txtDescricaoProdutoEditar;
    private javax.swing.JTextField txtEstoqueProduto;
    private javax.swing.JTextField txtEstoqueProdutoDetalhe;
    private javax.swing.JTextField txtFabricanteProduto;
    private javax.swing.JTextField txtFabricanteProdutoDetalhe;
    private javax.swing.JTextField txtFabricanteProdutoEditar;
    private javax.swing.JTextField txtNomeCategoria;
    private javax.swing.JTextField txtNomeProduto;
    private javax.swing.JTextField txtNomeProdutoDetalhe;
    private javax.swing.JTextField txtNomeProdutoEditar;
    private javax.swing.JTextField txtPesoProduto;
    private javax.swing.JTextField txtPesoProdutoDetalhe;
    private javax.swing.JTextField txtPesoProdutoEditar;
    private javax.swing.JTextField txtPesquisaProdutoEstoque;
    private javax.swing.JTextField txtPesquisarProdutoVenda;
    private javax.swing.JTextField txtPrecoCompraProduto;
    private javax.swing.JTextField txtPrecoCompraProdutoDetalhe;
    private javax.swing.JTextField txtPrecoCompraProdutoEditar;
    private javax.swing.JTextField txtPrecoVendaProduto;
    private javax.swing.JTextField txtPrecoVendaProdutoDetalhe;
    private javax.swing.JTextField txtPrecoVendaProdutoEditar;
    private javax.swing.JTextField txtProdutoEstoque;
    private javax.swing.JTextField txtProdutoVenda;
    private javax.swing.JTextField txtUnidadeMedidaProduto;
    private javax.swing.JTextField txtUnidadeMedidaProdutoDetalhe;
    private javax.swing.JTextField txtUnidadeMedidaProdutoEditar;
    private javax.swing.JTextField txtValorPagoVenda;
    // End of variables declaration//GEN-END:variables

    public JMenuItem getAdicionarProduto() {
        return AdicionarProduto;
    }

    public JMenuItem getControleEstoque() {
        return ControleEstoque;
    }

    public JMenu getEstoque() {
        return Estoque;
    }

    public JMenuItem getHistoricoVendas() {
        return HistoricoVendas;
    }

    public JMenuItem getListaProduto() {
        return ListaProduto;
    }

    public JMenuItem getRegistrarVenda() {
        return RegistrarVenda;
    }

    public JMenuItem getRelatorioVendas() {
        return RelatorioVendas;
    }

    public JMenu getVenda() {
        return Venda;
    }

    public JMenu getjMenu1() {
        return Financeiro;
    }

    public JMenu getjMenu2() {
        return Configurações;
    }

    public JMenuBar getjMenuBar2() {
        return jMenuBar2;
    }

    public JPanel getPainelPrincipal() {
        return painelPrincipal;
    }

    public JPanel getPainelRegistrarVenda() {
        return painelRegistrarVenda;
    }

    public JMenu getAjuda() {
        return Ajuda;
    }

    public JPanel getPainelHistoricoVendas() {
        return painelHistoricoVendas;
    }

    public JPanel getPainelListaProduto() {
        return painelListaProduto;
    }

    public JPanel getPainelRegistrarProduto() {
        return painelRegistrarProduto;
    }

    public JPanel getPainelControleEstoque() {
        return painelControleEstoque;
    }

    public JButton getBtnCancelarCategoria() {
        return btnCancelarCategoria;
    }

    public JButton getBtnSalvarCategoria() {
        return btnSalvarCategoria;
    }

    public JDialog getTelaCategoria() {
        return telaCategoria;
    }

    public JTextField getTxtNomeCategoria() {
        return txtNomeCategoria;
    }

    public JButton getBtnCategoria() {
        return btnCategoria;
    }

    public JComboBox<String> getComboBoxCategoria() {
        return ComboBoxCategoria;
    }

    public JTextField getTxtCodigoProduto() {
        return txtCodigoProduto;
    }

    public JTextArea getTxtDescricaoProduto() {
        return txtDescricaoProduto;
    }

    public JTextField getTxtEstoqueProduto() {
        return txtEstoqueProduto;
    }

    public JTextField getTxtFabricanteProduto() {
        return txtFabricanteProduto;
    }

    public JTextField getTxtNomeProduto() {
        return txtNomeProduto;
    }

    public JTextField getTxtPesoProduto() {
        return txtPesoProduto;
    }

    public JTextField getTxtPrecoCompraProduto() {
        return txtPrecoCompraProduto;
    }

    public JTextField getTxtPrecoVendaProduto() {
        return txtPrecoVendaProduto;
    }

    public JTextField getTxtUnidadeMedidaProduto() {
        return txtUnidadeMedidaProduto;
    }

    public JTable getTabelaListaProduto() {
        return tabelaListaProduto;
    }

    public JComboBox<String> getComboBoxCategoriaEditar() {
        return comboBoxCategoriaEditar;
    }

    public JDialog getTelaEditarProduto() {
        return telaEditarProduto;
    }

    public JTextField getTxtCodigoProdutoEditar() {
        return txtCodigoProdutoEditar;
    }

    public JTextArea getTxtDescricaoProdutoEditar() {
        return txtDescricaoProdutoEditar;
    }

    public JTextField getTxtFabricanteProdutoEditar() {
        return txtFabricanteProdutoEditar;
    }

    public JTextField getTxtNomeProdutoEditar() {
        return txtNomeProdutoEditar;
    }

    public JTextField getTxtPesoProdutoEditar() {
        return txtPesoProdutoEditar;
    }

    public JTextField getTxtPrecoCompraProdutoEditar() {
        return txtPrecoCompraProdutoEditar;
    }

    public JTextField getTxtPrecoVendaProdutoEditar() {
        return txtPrecoVendaProdutoEditar;
    }

    public JTextField getTxtUnidadeMedidaProdutoEditar() {
        return txtUnidadeMedidaProdutoEditar;
    }

    public JButton getBtnEditarProduto() {
        return btnEditarProduto;
    }

    public JTextField getTxtCategoriaProdutoDetalhe() {
        return txtCategoriaProdutoDetalhe;
    }

    public JDialog getTelaDetalheProduto() {
        return telaDetalheProduto;
    }

    public JTextField getTxtCodigoProdutoDetalhe() {
        return txtCodigoProdutoDetalhe;
    }

    public JTextArea getTxtDescricaoProdutoDetalhe() {
        return txtDescricaoProdutoDetalhe;
    }
    
    public JTextField getTxtEstoqueProdutoDetalhe(){
        return txtEstoqueProdutoDetalhe;
    }

    public JTextField getTxtFabricanteProdutoDetalhe() {
        return txtFabricanteProdutoDetalhe;
    }

    public JTextField getTxtNomeProdutoDetalhe() {
        return txtNomeProdutoDetalhe;
    }

    public JTextField getTxtPesoProdutoDetalhe() {
        return txtPesoProdutoDetalhe;
    }

    public JTextField getTxtPrecoCompraProdutoDetalhe() {
        return txtPrecoCompraProdutoDetalhe;
    }

    public JTextField getTxtPrecoVendaProdutoDetalhe() {
        return txtPrecoVendaProdutoDetalhe;
    }

    public JTextField getTxtUnidadeMedidaProdutoDetalhe() {
        return txtUnidadeMedidaProdutoDetalhe;
    }

    public JSpinner getSpinnerMaximoEstoque() {
        return spinnerMaximoEstoque;
    }

    public JSpinner getSpinnerMinimoEstoque() {
        return spinnerMinimoEstoque;
    }

    public JSpinner getSpinnerQuantidadeEstoque() {
        return spinnerQuantidadeEstoque;
    }

    public JTable getTabelaControleEstoque() {
        return tabelaControleEstoque;
    }

    public JTable getTabelaRegistrarVenda() {
        return tabelaRegistrarVenda;
    }

    public JTextField getTxtPesquisaProdutoEstoque() {
        return txtPesquisaProdutoEstoque;
    }

    public JTextField getTxtProdutoEstoque() {
        return txtProdutoEstoque;
    }

    public JTextField getTxtPesquisarProdutoVenda() {
        return txtPesquisarProdutoVenda;
    }

    public JSpinner getSpinnerQuantidadeVenda() {
        return spinnerQuantidadeVenda;
    }

    public JTable getTabelaHistoricoVendas() {
        return tabelaHistoricoVendas;
    }

    public JTextField getTxtProdutoVenda() {
        return txtProdutoVenda;
    }

    public JTextField getTxtValorPagoVenda() {
        return txtValorPagoVenda;
    }

    public JComboBox<String> getComboBoxPagamento() {
        return comboBoxPagamento;
    }
    
}
