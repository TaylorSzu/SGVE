package controller;

import dao.CategoriaDAO;
import dao.ConexaoMySql;
import dao.ProdutoDAO;
import entidades.Categoria;
import entidades.Produto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.math.BigDecimal;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.DefaultComboBoxModel;

import javax.swing.JOptionPane;

import model.ProdutoTableModel;
import view.Dashboard;

public class ProdutoController implements ActionListener, KeyListener, MouseListener{
    
    private final Dashboard dashboard;
    private ProdutoDAO produtoDAO;
    private CategoriaDAO categoriaDAO;
    private Produto produto;
    private Produto produtoEmEdicao;
    private List<Produto> produtos;
    private ProdutoTableModel produtoTableModel;

    public ProdutoController(Dashboard dashboard) {
        this.dashboard = dashboard;
        this.produtoDAO = new ProdutoDAO();
        this.categoriaDAO = new CategoriaDAO();
        this.produtos = produtoDAO.listarProduto();
        this.produtoTableModel = new ProdutoTableModel(new ArrayList<>());
        dashboard.getTabelaListaProduto().setModel(produtoTableModel);
        atualizarTabela(produtos);
        preencherTabela();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String acao = e.getActionCommand().toLowerCase();
        
        switch (acao) {
            case "cadastrar" : Cadastrar(); break;
            case "cancelar" : Cancelar(); break;
            case "detalhes" : Detalhes(); break;
            case "editar" : Editar(); break;
            case "excluir" : Excluir(); break;
            case "salvar" : Salvar(); break;
        }
    }

    private void Cadastrar() {
        cadastrarProduto();
        limparCampos();
        preencherTabela();
        atualizarTabela(produtos);
    }
    
    private void Salvar(){
        editarProduto();
        atualizarTabela(produtos);
        limparCampos();
    }

    private void Cancelar() {
        this.dashboard.getTelaEditarProduto().setVisible(false);
        limparCampos();
    }
    
    private void Detalhes(){
        if(produto != null){
            mostrarTelaDetalhe();
            preencherCamposDetalhes();
        }else{
            JOptionPane.showMessageDialog(null, "Selecione um produto para ver os detalhes.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void Editar(){
        if (produto != null) {
            mostrarTelaEditar();
            preencherCamposEdicao();
        } else {
            JOptionPane.showMessageDialog(null, "Selecione um produto para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void Excluir() {
        if (produto != null) {
            int confirmar = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir este Produto?", "Confirmar exclusão", JOptionPane.YES_NO_OPTION);
            if (confirmar == JOptionPane.YES_OPTION) {
                produtoDAO.deletarProduto(produto);
                preencherTabela();
                atualizarTabela(produtoDAO.listarProduto());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecione um produto para excluir.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }   
    
    private void mostrarTelaEditar() {
        this.dashboard.getTelaEditarProduto().pack();
        this.dashboard.getTelaEditarProduto().setLocationRelativeTo(dashboard);
        this.dashboard.getTelaEditarProduto().setVisible(true);
    }
    
    private void mostrarTelaDetalhe(){
        this.dashboard.getTelaDetalheProduto().pack();
        this.dashboard.getTelaDetalheProduto().setLocationRelativeTo(dashboard);
        this.dashboard.getTelaDetalheProduto().setVisible(true);
    }
    
    private void cadastrarProduto(){
        Connection Conexao = new ConexaoMySql().obterConexao();
        ProdutoDAO produtoDAO = new ProdutoDAO();
        
        String codigoStr, nome, fabricante, categoria, unidadeMedida, descricao, pesoStr, estoqueStr;
        BigDecimal preco_compra, preco_venda;
        Long codigo;
        int estoque;
        float peso;
        
        codigoStr = dashboard.getTxtCodigoProduto().getText();
        codigo = Long.parseLong(codigoStr);
        nome = dashboard.getTxtNomeProduto().getText();
        fabricante = dashboard.getTxtFabricanteProduto().getText();
        categoria = dashboard.getComboBoxCategoria().getSelectedItem().toString();
        pesoStr = dashboard.getTxtPesoProduto().getText();
        peso = Float.parseFloat(pesoStr);
        unidadeMedida = dashboard.getTxtUnidadeMedidaProduto().getText();
        preco_compra = new BigDecimal(dashboard.getTxtPrecoCompraProduto().getText());
        preco_venda = new BigDecimal(dashboard.getTxtPrecoVendaProduto().getText());
        estoqueStr = dashboard.getTxtEstoqueProduto().getText();
        estoque = Integer.parseInt(estoqueStr);
        descricao = dashboard.getTxtDescricaoProduto().getText();
        
        Produto produto = new Produto(codigo, nome, fabricante, categoria, peso, unidadeMedida, preco_compra, preco_venda, estoque, descricao);
        
        produtoDAO.cadastrarProduto(produto);
    }
    
    private void editarProduto(){
        Connection Conexao = new ConexaoMySql().obterConexao();
        ProdutoDAO produtoDAO = new ProdutoDAO();
        
        String codigoStr, nome, fabricante, categoria, unidadeMedida, descricao, pesoStr, estoqueStr;
        BigDecimal preco_compra, preco_venda;
        Long codigo;
        int estoque;
        float peso;
        
        codigoStr = dashboard.getTxtCodigoProdutoEditar().getText();
        codigo = Long.parseLong(codigoStr);
        nome = dashboard.getTxtNomeProdutoEditar().getText();
        fabricante = dashboard.getTxtFabricanteProdutoEditar().getText();
        categoria = dashboard.getComboBoxCategoriaEditar().getSelectedItem().toString();
        pesoStr = dashboard.getTxtPesoProdutoEditar().getText();
        peso = Float.parseFloat(pesoStr);
        unidadeMedida = dashboard.getTxtUnidadeMedidaProdutoEditar().getText();
        preco_compra = new BigDecimal(dashboard.getTxtPrecoCompraProdutoEditar().getText());
        preco_venda = new BigDecimal(dashboard.getTxtPrecoVendaProdutoEditar().getText());
        descricao = dashboard.getTxtDescricaoProdutoEditar().getText();
        
        Produto produto = new Produto(codigo, nome, fabricante, categoria, 0, unidadeMedida, preco_compra, preco_venda, descricao);
        
        produtoDAO.atualizarProduto(produto);
    }
    
    private void preencherCamposEdicao() {
        dashboard.getTxtCodigoProdutoEditar().setText(String.valueOf(produto.getCodigo()));
        dashboard.getTxtNomeProdutoEditar().setText(produto.getNome());
        dashboard.getTxtFabricanteProdutoEditar().setText(produto.getFabricante());
        dashboard.getComboBoxCategoriaEditar().setSelectedItem(produto.getCategoria());
        dashboard.getTxtPesoProdutoEditar().setText(String.valueOf(produto.getPeso()));
        dashboard.getTxtUnidadeMedidaProdutoEditar().setText(produto.getUnidadeMedida());
        dashboard.getTxtPrecoCompraProdutoEditar().setText(String.valueOf(produto.getPrecoCompra()));
        dashboard.getTxtPrecoVendaProdutoEditar().setText(String.valueOf(produto.getPrecoVenda()));
        dashboard.getTxtDescricaoProdutoEditar().setText(produto.getDescricao());
        carregarCategoriaEditar();
    }
    
    private void preencherCamposDetalhes() {
        dashboard.getTxtCodigoProdutoDetalhe().setText(String.valueOf(produto.getCodigo()));
        dashboard.getTxtNomeProdutoDetalhe().setText(produto.getNome());
        dashboard.getTxtFabricanteProdutoDetalhe().setText(produto.getFabricante());
        dashboard.getTxtCategoriaProdutoDetalhe().setText(produto.getCategoria());
        dashboard.getTxtPesoProdutoDetalhe().setText(String.valueOf(produto.getPeso()));
        dashboard.getTxtUnidadeMedidaProdutoDetalhe().setText(produto.getUnidadeMedida());
        dashboard.getTxtPrecoCompraProdutoDetalhe().setText(String.valueOf(produto.getPrecoCompra()));
        dashboard.getTxtPrecoVendaProdutoDetalhe().setText(String.valueOf(produto.getPrecoVenda()));
        dashboard.getTxtEstoqueProdutoDetalhe().setText(String.valueOf(produto.getEstoque()));
        dashboard.getTxtDescricaoProdutoDetalhe().setText(produto.getDescricao());
    }
    
    private void limparCampos(){
        this.dashboard.getTxtCodigoProduto().setText("");
        this.dashboard.getTxtNomeProduto().setText("");
        this.dashboard.getTxtFabricanteProduto().setText("");
        this.dashboard.getComboBoxCategoria().setSelectedItem(null);
        this.dashboard.getTxtPesoProduto().setText("");
        this.dashboard.getTxtUnidadeMedidaProduto().setText("");
        this.dashboard.getTxtPrecoCompraProduto().setText("");
        this.dashboard.getTxtPrecoVendaProduto().setText("");
        this.dashboard.getTxtEstoqueProduto().setText("");
        this.dashboard.getTxtDescricaoProduto().setText("");
    }
    
    private void preencherTabela(){
        List<Produto> produtos = produtoDAO.listarProduto();
        ProdutoTableModel modeloTabela = new ProdutoTableModel(produtos);
        dashboard.getTabelaListaProduto().setModel(modeloTabela);
        atualizarTabela(produtos);
    }
    
    
    private void atualizarTabela(List<Produto> produtos){
        produtoTableModel.setProdutos(produtos);
        dashboard.getTabelaListaProduto().repaint();
        dashboard.getTabelaListaProduto().revalidate();
    }
    
    private void carregarCategoriaEditar(){
        List<Categoria> categorias =  categoriaDAO.listarCategoria();
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        for (Categoria categoria : categorias) {
            model.addElement(categoria.getCategoria());
        }
        this.dashboard.getComboBoxCategoriaEditar().setModel(model);
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void mouseClicked(MouseEvent e) {
        int linhaSelecionada = this.dashboard.getTabelaListaProduto().getSelectedRow();
        if(linhaSelecionada != -1 && linhaSelecionada < produtoTableModel.getRowCount()){
            this.produto = this.produtoTableModel.getProdutos().get(linhaSelecionada);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}    
}
