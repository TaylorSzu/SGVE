package controller;

import dao.ProdutoDAO;
import entidades.Produto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import model.PesquisaEstoqueTableModel;
import view.Dashboard;

public class EstoqueController implements ActionListener, KeyListener, MouseListener {
    
    private Dashboard dashboard;
    private ProdutoDAO produtoDAO;
    private Produto produto;
    private Produto produtoEmEdicao;
    private List<Produto> produtos;
    private PesquisaEstoqueTableModel pesquisaEstoqueTableModel;

    public EstoqueController(Dashboard dashboard) {
        this.dashboard = dashboard;
        this.produtoDAO = new ProdutoDAO();
        this.produtos = produtoDAO.listarProduto();
        this.pesquisaEstoqueTableModel = new PesquisaEstoqueTableModel(new ArrayList<>());
        dashboard.getTxtPesquisaProdutoEstoque().addKeyListener(this);
        dashboard.getTabelaControleEstoque().addMouseListener(this);
        dashboard.getTabelaControleEstoque().setModel(pesquisaEstoqueTableModel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String acao = e.getActionCommand().toLowerCase();
        
        switch (acao) {
            case "adicionar" : adicionar(); break;
            case "cancelar" : cancelar();break;
        }
    }

    private void adicionar() {
        // Lógica para adicionar um novo produto
    }

    private void cancelar() {
        // Lógica para cancelar a operação
    }
    
    private void pesquisar() {
        String pesquisa = dashboard.getTxtPesquisaProdutoEstoque().getText().toLowerCase().trim();
        List<Produto> produtosEncontrados = produtos.stream()
                .filter(p -> p.getNome().toLowerCase().contains(pesquisa))
                .collect(Collectors.toList());
        System.out.println("Produto Encontrado");
        atualizarTabela(produtosEncontrados);
    }
    
    private void atualizarTabela(List<Produto> produtos) {
        pesquisaEstoqueTableModel.setProdutos(produtos);
        dashboard.getTabelaControleEstoque().repaint();
        dashboard.getTabelaControleEstoque().revalidate();
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {
        pesquisar();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int linhaSelecionada = this.dashboard.getTabelaControleEstoque().getSelectedRow();
        if (linhaSelecionada != -1 && linhaSelecionada < pesquisaEstoqueTableModel.getRowCount()) {
            this.produto = this.pesquisaEstoqueTableModel.getProdutos().get(linhaSelecionada);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}
}
