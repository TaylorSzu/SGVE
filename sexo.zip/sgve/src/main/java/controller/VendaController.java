package controller;

import dao.ConexaoMySql;
import dao.ProdutoDAO;
import dao.VendaDAO;
import entidades.Produto;
import entidades.Venda;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.math.BigDecimal;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import model.PesquisaVendaTableModel;
import model.VendaTableModel;
import view.Dashboard;

public class VendaController implements ActionListener, KeyListener, MouseListener, ChangeListener{
    
    private Dashboard dashboard;
    private ProdutoDAO produtoDAO;
    private VendaDAO vendaDAO;
    private Produto produto;
    private Venda venda;
    private Produto produtoEmEdicao;
    private List<Produto> produtos;
    private List<Venda> vendas;
    private PesquisaVendaTableModel pesquisaVendaTableModel;
    private VendaTableModel vendaTableModel;
    private BigDecimal lucro;

    public VendaController(Dashboard dashboard) {
        this.dashboard = dashboard;
        this.produtoDAO = new ProdutoDAO();
        this.vendaDAO = new VendaDAO();
        this.vendas = vendaDAO.HistoricoVenda();
        this.produtos = produtoDAO.listarProduto();
        this.pesquisaVendaTableModel = new PesquisaVendaTableModel(new ArrayList<>());
        this.vendaTableModel = new VendaTableModel(new ArrayList<>());
        this.lucro = BigDecimal.ZERO;
        dashboard.getTxtPesquisarProdutoVenda().addKeyListener(this);
        dashboard.getTxtValorPagoVenda().addKeyListener(this);
        dashboard.getTabelaRegistrarVenda().addMouseListener(this);
        dashboard.getSpinnerQuantidadeVenda().addChangeListener(this);
        dashboard.getTabelaRegistrarVenda().setModel(pesquisaVendaTableModel);
        dashboard.getTabelaHistoricoVendas().setModel(vendaTableModel);
        atualizarTabelaVenda(vendaDAO.HistoricoVenda());
        preencherTabela();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String acao = e.getActionCommand().toLowerCase().trim();
        
        switch (acao) {
            case "vender" : Vender(); break;
            case "excluir" : Excluir(); break;
            case "salvar" : Salvar(); break;
        }
    }
    
    private void Vender(){
        registrarVenda();
        limparCampos();
        JOptionPane.showMessageDialog(null, "Venda Registrada com sucesso", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void Excluir() {
        if (venda != null) {
            int confirmar = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir esta venda?", "Confirmar exclusão", JOptionPane.YES_NO_OPTION);
            if (confirmar == JOptionPane.YES_OPTION) {
                vendaDAO.deletarVenda(venda);
                preencherTabela();
                atualizarTabelaVenda(vendaDAO.HistoricoVenda());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecione um produto para excluir.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void Salvar(){
        
    }
    
    private void registrarVenda(){
        Connection Conexao = new ConexaoMySql().obterConexao();
        VendaDAO vendaDAO = new VendaDAO();
        
        String produto, pagamento, valorPagoStr;
        int quantidade;
        
        produto = dashboard.getTxtProdutoVenda().getText();
        pagamento = dashboard.getComboBoxPagamento().getSelectedItem().toString();
        quantidade = (int) dashboard.getSpinnerQuantidadeVenda().getValue();
        valorPagoStr = dashboard.getTxtValorPagoVenda().getText();
        BigDecimal valorPago = new BigDecimal(valorPagoStr);
        lucro = lucro.add(valorPago);   
        
        Venda venda = new Venda(produto, quantidade, valorPago, pagamento);
        vendaDAO.registrarVenda(venda);
        produtoDAO.atualizarEstoqueProduto(produto, quantidade);
        preencherTabela();
        this.dashboard.getLabelTotal().setText("R$" + lucro.toString());
    }
    
    private void preencherTabela(){
        List<Venda> vendas = vendaDAO.HistoricoVenda();
        VendaTableModel modeloTabela = new VendaTableModel(vendas);
        dashboard.getTabelaHistoricoVendas().setModel(modeloTabela);
        atualizarTabelaVenda(vendaDAO.HistoricoVenda());
    }
    
    private void pesquisar() {
        String pesquisa = dashboard.getTxtPesquisarProdutoVenda().getText().toLowerCase().trim();
        List<Produto> produtosEncontrados = produtos.stream()
                .filter(p -> p.getNome().toLowerCase().contains(pesquisa))
                .collect(Collectors.toList());
        System.out.println("Produto Encontrado");
        atualizarTabela(produtosEncontrados);
    }
    
    private void atualizarTabelaVenda(List<Venda> vendas){
        vendaTableModel.setVendas(vendas);
        dashboard.getTabelaHistoricoVendas().repaint();
        dashboard.getTabelaHistoricoVendas().revalidate();
        this.dashboard.getLabelVenda().setText(String.format("%d", vendas.size()));
    }
    
    private void atualizarTabela(List<Produto> produtos) {
        pesquisaVendaTableModel.setProdutos(produtos);
        dashboard.getTabelaControleEstoque().repaint();
        dashboard.getTabelaControleEstoque().revalidate();
    }
    
    private void atualizarEstoque(){
        
    }
    
    private void limparCampos(){
        dashboard.getTxtPesquisarProdutoVenda().setText("");
        dashboard.getTxtProdutoVenda().setText("");
        dashboard.getSpinnerQuantidadeVenda().setValue(0);
        dashboard.getTxtValorPagoVenda().setText("");
        dashboard.getComboBoxPagamento().setSelectedItem("Pix");
        dashboard.getLabelTotalVenda().setText("0.00");
        dashboard.getLabelValorPago().setText("0.00");
        dashboard.getLabelTroco().setText("0.00");
    }
    
    private void calcularValor(){
        int linhaSelecionada = dashboard.getTabelaRegistrarVenda().getSelectedRow();
        String nomeProduto = dashboard.getTxtProdutoVenda().getText().toLowerCase().trim();
        Produto produtoSelecionado = null;
        
        for(Produto produto : produtos){
            if(produto.getNome().equalsIgnoreCase(nomeProduto)){
                produtoSelecionado = produto;
                break;
            }
        }
        
        if(produtoSelecionado != null){
            BigDecimal precoUnitario = produtoSelecionado.getPrecoVenda();
            int quantidade = (int) dashboard.getSpinnerQuantidadeVenda().getValue();
            BigDecimal valorTotal = precoUnitario.multiply(BigDecimal.valueOf(quantidade));
            dashboard.getLabelTotalVenda().setText(valorTotal.toString());
        }
    }
    
    private void valorPago(){
        String valorPagoTxt = dashboard.getTxtValorPagoVenda().getText().trim();
        if(valorPagoTxt != null && !valorPagoTxt.isEmpty()){
            try {
                BigDecimal valorPago = new BigDecimal(valorPagoTxt);
                String valorTotalTxt = dashboard.getLabelTotalVenda().getText();
                BigDecimal valorTotal = new BigDecimal(valorTotalTxt);
                BigDecimal troco = valorPago.subtract(valorTotal);
                String valorPagoFormt = valorPago.setScale(2, BigDecimal.ROUND_HALF_EVEN).toString();
                dashboard.getLabelValorPago().setText(valorPagoFormt);
                dashboard.getLabelTroco().setText(troco.toString());
                dashboard.getLabelValorPago().setText(valorPagoTxt);
            } catch (NumberFormatException erro) {
                System.err.println("Erro ao converter o valor pago para BigDecimal: " + erro.getMessage());
                erro.printStackTrace();
            }
        }
    }
    
    private void selecionarItem(){
        int linhaSelecionada = this.dashboard.getTabelaHistoricoVendas().getSelectedRow();
        if(linhaSelecionada != -1 && linhaSelecionada < vendaTableModel.getRowCount()){
            this.venda = this.vendaTableModel.getProdutos().get(linhaSelecionada);
        }
    }
    
    private void SetarNomeProduto(){
        int linhaSelecionada = dashboard.getTabelaRegistrarVenda().getSelectedRow();
        if(linhaSelecionada != -1){
            String nomeProduto = (String) dashboard.getTabelaRegistrarVenda().getValueAt(linhaSelecionada, 1);
            dashboard.getTxtProdutoVenda().setText(nomeProduto);
        }   
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {
        pesquisar();
        valorPago();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        selecionarItem();
        SetarNomeProduto();
    }

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void stateChanged(ChangeEvent e) {
        calcularValor();
    }
}
