package controller;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import view.Dashboard;

public class DashboardController implements ActionListener{

    private final Dashboard dashboard;

    public DashboardController(Dashboard dashboard) {
        this.dashboard = dashboard;
    }
    
    public void inserirIcone(JFrame view){
        try {
            view.setIconImage(Toolkit.getDefaultToolkit().getImage("src/main/java/resources/ponto-de-venda.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String acao = e.getActionCommand().toLowerCase();
        
        switch (acao) {
            case "registrar venda" : painelRegistrarVenda(); break;
            case "historico de vendas" : painelHistoricoVendas(); break;
            case "adicionar produto" : painelAdicionarProduto(); break;
            case "lista de produtos" : painelListaProduto(); break;
            case "controle de estoque" : painelControleEstoque(); break;
            case "estatisticas" : painelEstatisticas(); break;
            case "relatorio de vendas" : painelRelatorio(); break;
            case "suporte" : painelSuporte(); break;
            case "novo produto" : btnNovoProduto(); break;
            case "nova venda" : btnNovaVenda(); break;
        }
    }
    
    private void painelComponentes(JPanel panel){
        this.dashboard.getPainelPrincipal().removeAll();
        this.dashboard.getPainelPrincipal().repaint();
        this.dashboard.getPainelPrincipal().revalidate();
        this.dashboard.getPainelPrincipal().add(panel);
        this.dashboard.getPainelPrincipal().repaint();
        this.dashboard.getPainelPrincipal().revalidate();
    }
    
    private void painelComponentes(JTabbedPane panel){
        this.dashboard.getPainelPrincipal().removeAll();
        this.dashboard.getPainelPrincipal().repaint();
        this.dashboard.getPainelPrincipal().revalidate();
        this.dashboard.getPainelPrincipal().add(panel);
        this.dashboard.getPainelPrincipal().repaint();
        this.dashboard.getPainelPrincipal().revalidate();
    }

    private void painelRegistrarVenda() {
        painelComponentes(this.dashboard.getPainelRegistrarVenda());
    }

    private void painelHistoricoVendas() {
        painelComponentes(this.dashboard.getPainelHistoricoVendas());
    }

    private void painelAdicionarProduto() {
        painelComponentes(this.dashboard.getPainelRegistrarProduto());
    }

    private void painelListaProduto() {
        painelComponentes(this.dashboard.getPainelListaProduto());
    }

    private void painelControleEstoque() {
        painelComponentes(this.dashboard.getPainelControleEstoque());
    }

    private void painelEstatisticas() {
        painelComponentes(this.dashboard.getPainelEstatisticas());
    }
    
    private void painelRelatorio(){
        painelComponentes(this.dashboard.getPainelRelatorio());
    }
    
    private void painelSuporte(){
        painelComponentes(this.dashboard.getPainelSuporte());
    }

    private void btnNovoProduto() {
        painelComponentes(this.dashboard.getPainelRegistrarProduto());
    }

    private void btnNovaVenda() {
        painelComponentes(this.dashboard.getPainelRegistrarVenda());
    }
    
}
