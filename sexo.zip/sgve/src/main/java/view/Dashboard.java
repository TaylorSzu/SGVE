package view;

import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import controller.CategoriaController;
import controller.DashboardController;
import controller.EstoqueController;
import controller.ProdutoController;
import controller.VendaController;
import java.awt.Component;
import java.awt.Container;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Dashboard extends javax.swing.JFrame {

    private DashboardController dashboardController;
    private CategoriaController categoriaController;
    private ProdutoController produtoController;
    private EstoqueController estoqueController;
    private VendaController vendaController;
    
    public Dashboard() {
        initComponents();
        this.dashboardController = new DashboardController(this);
        this.categoriaController = new CategoriaController(this);
        this.produtoController = new ProdutoController(this);
        this.estoqueController = new EstoqueController(this);
        this.vendaController = new VendaController(this);
        dashboardController.inserirIcone(this);
        setLocationRelativeTo(null);
        eventosDashboard();
        eventosCategoria();
        eventosProduto();
        eventosEstoque();
        eventosVenda();
    }
    
    private void eventosDashboard(){
        RegistrarVenda.addActionListener(dashboardController);
        HistoricoVendas.addActionListener(dashboardController);
        AdicionarProduto.addActionListener(dashboardController);
        ListaProduto.addActionListener(dashboardController);
        ControleEstoque.addActionListener(dashboardController);
        Estatisticas.addActionListener(dashboardController);
        RelatorioVendas.addActionListener(dashboardController);
        Suporte.addActionListener(dashboardController);
        btnNovoProduto.addActionListener(dashboardController);
        btnNovaVenda.addActionListener(dashboardController);
    }
    
    private void eventosProduto(){
        btnCadastrarProduto.addActionListener(produtoController);
        btnDetalheProduto.addActionListener(produtoController);
        btnEditarProduto.addActionListener(produtoController);
        btnExcluirProduto.addActionListener(produtoController);
        btnSalvarProdutoEditar.addActionListener(produtoController);
        tabelaListaProduto.addMouseListener(produtoController);
    }
    
    private void eventosEstoque(){
        btnAddEstoque.addActionListener(estoqueController);
        tabelaControleEstoque.addMouseListener(estoqueController);
    }
    
    private void eventosVenda(){
        btnVenderVenda.addActionListener(vendaController);
        btnExcluirVenda.addActionListener(vendaController);
        tabelaHistoricoVendas.addMouseListener(vendaController);
        
    }
    
    private void eventosCategoria(){
        btnSalvarCategoria.addActionListener(categoriaController);
        btnCancelarCategoria.addActionListener(categoriaController);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        telaCategoria = new javax.swing.JDialog();
        jLabel34 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        txtNomeCategoria = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        btnCancelarCategoria = new javax.swing.JButton();
        btnSalvarCategoria = new javax.swing.JButton();
        telaEditarProduto = new javax.swing.JDialog();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        txtNomeProdutoEditar = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        txtFabricanteProdutoEditar = new javax.swing.JTextField();
        txtCodigoProdutoEditar = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        comboBoxCategoriaEditar = new javax.swing.JComboBox<>();
        jLabel43 = new javax.swing.JLabel();
        txtPesoProdutoEditar = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        txtUnidadeMedidaProdutoEditar = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        txtPrecoCompraProdutoEditar = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        txtPrecoVendaProdutoEditar = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        btnCancelarEditar = new javax.swing.JButton();
        btnSalvarProdutoEditar = new javax.swing.JButton();
        txtIdProdutoEditar = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDescricaoProdutoEditar = new javax.swing.JTextArea();
        telaDetalheProduto = new javax.swing.JDialog();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        txtNomeProdutoDetalhe = new javax.swing.JTextField();
        jLabel52 = new javax.swing.JLabel();
        txtFabricanteProdutoDetalhe = new javax.swing.JTextField();
        txtCodigoProdutoDetalhe = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        txtPesoProdutoDetalhe = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        txtUnidadeMedidaProdutoDetalhe = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        txtPrecoCompraProdutoDetalhe = new javax.swing.JTextField();
        jLabel58 = new javax.swing.JLabel();
        txtPrecoVendaProdutoDetalhe = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        txtEstoqueProdutoDetalhe = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtDescricaoProdutoDetalhe = new javax.swing.JTextArea();
        txtCategoriaProdutoDetalhe = new javax.swing.JTextField();
        painelPrincipal = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        painelRegistrarVenda = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabelaRegistrarVenda = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        txtPesquisarProdutoVenda = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtProdutoVenda = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        spinnerQuantidadeVenda = new javax.swing.JSpinner();
        txtValorPagoVenda = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        rbVendaPesoSim = new javax.swing.JRadioButton();
        rbVendaPesoNao = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        comboBoxPagamento = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        btnCancelarVenda = new javax.swing.JButton();
        btnVenderVenda = new javax.swing.JButton();
        panel1 = new view.Panel();
        jLabel2 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        labelTroco = new javax.swing.JLabel();
        labelTotalVenda = new javax.swing.JLabel();
        labelValorPago = new javax.swing.JLabel();
        painelListaProduto = new javax.swing.JPanel();
        btnExcluirProduto = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabelaListaProduto = new javax.swing.JTable();
        btnDetalheProduto = new javax.swing.JButton();
        btnEditarProduto = new javax.swing.JButton();
        painelHistoricoVendas = new javax.swing.JPanel();
        btnExcluirVenda = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tabelaHistoricoVendas = new javax.swing.JTable();
        painelControleEstoque = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtPesquisaProdutoEstoque = new javax.swing.JTextField();
        txtProdutoEstoque = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        spinnerQuantidadeEstoque = new javax.swing.JSpinner();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaControleEstoque = new javax.swing.JTable();
        btnAddEstoque = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        txtProdutoEstoqueMinimo = new javax.swing.JTextField();
        txtProdutoEstoqueMaximo = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        txtProdutoEstoqueID = new javax.swing.JTextField();
        painelRegistrarProduto = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        txtEstoqueMaximoProduto = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        txtNomeProduto = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        btnCadastrarProduto = new javax.swing.JButton();
        txtFabricanteProduto = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        txtCodigoProduto = new javax.swing.JTextField();
        txtPrecoCompraProduto = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtEstoqueProduto = new javax.swing.JTextField();
        txtPesoProduto = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        btnCategoria = new javax.swing.JButton();
        txtUnidadeMedidaProduto = new javax.swing.JTextField();
        btnCancelarProduto = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        txtPrecoVendaProduto = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtDescricaoProduto = new javax.swing.JTextArea();
        jLabel18 = new javax.swing.JLabel();
        ComboBoxCategoria = new javax.swing.JComboBox<>();
        txtEstoqueMinimoProduto = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        painelEstatisticas = new javax.swing.JPanel();
        panel2 = new view.Panel();
        btnNovoProduto = new javax.swing.JButton();
        labelProdutos = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        panel3 = new view.Panel();
        jLabel62 = new javax.swing.JLabel();
        labelVenda = new javax.swing.JLabel();
        btnNovaVenda = new javax.swing.JButton();
        panel4 = new view.Panel();
        btnNovoProduto2 = new javax.swing.JButton();
        labelTotal = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        painelRelatorio = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel63 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton5 = new javax.swing.JButton();
        painelSuporte = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        Menubar = new javax.swing.JMenuBar();
        Venda = new javax.swing.JMenu();
        RegistrarVenda = new javax.swing.JMenuItem();
        HistoricoVendas = new javax.swing.JMenuItem();
        RelatorioVendas = new javax.swing.JMenuItem();
        Estoque = new javax.swing.JMenu();
        AdicionarProduto = new javax.swing.JMenuItem();
        ListaProduto = new javax.swing.JMenuItem();
        ControleEstoque = new javax.swing.JMenuItem();
        Financeiro = new javax.swing.JMenu();
        Estatisticas = new javax.swing.JMenuItem();
        Configurações = new javax.swing.JMenu();
        Tema = new javax.swing.JMenu();
        ModoClaro = new javax.swing.JMenuItem();
        ModoEscuro = new javax.swing.JMenuItem();
        Ajuda = new javax.swing.JMenu();
        Suporte = new javax.swing.JMenuItem();

        telaCategoria.setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        telaCategoria.setMinimumSize(new java.awt.Dimension(720, 280));
        telaCategoria.setUndecorated(true);

        jLabel34.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("NOVA CATEGORIA");

        jTextField4.setEditable(false);
        jTextField4.setText("0");

        jLabel35.setText("Id");

        jLabel36.setText("Nome");

        btnCancelarCategoria.setText("Cancelar");
        btnCancelarCategoria.setPreferredSize(new java.awt.Dimension(115, 45));

        btnSalvarCategoria.setText("Salvar");
        btnSalvarCategoria.setPreferredSize(new java.awt.Dimension(99, 45));

        javax.swing.GroupLayout telaCategoriaLayout = new javax.swing.GroupLayout(telaCategoria.getContentPane());
        telaCategoria.getContentPane().setLayout(telaCategoriaLayout);
        telaCategoriaLayout.setHorizontalGroup(
            telaCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(telaCategoriaLayout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(telaCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel36)
                    .addComponent(jLabel35)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNomeCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(68, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaCategoriaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSalvarCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCancelarCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );
        telaCategoriaLayout.setVerticalGroup(
            telaCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(telaCategoriaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNomeCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(telaCategoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSalvarCategoria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCancelarCategoria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel38.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("EDITAR PRODUTO");

        jLabel39.setText("Nome");

        jLabel40.setText("Fabricante");

        jLabel41.setText("Codigo");

        jLabel42.setText("Categoria");

        jLabel43.setText("Peso");

        jLabel44.setText("Unidade de Medida");

        txtUnidadeMedidaProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUnidadeMedidaProdutoEditarActionPerformed(evt);
            }
        });

        jLabel45.setText("Preço de Compra");

        txtPrecoCompraProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoCompraProdutoEditarActionPerformed(evt);
            }
        });

        jLabel46.setText("Preço de Venda");

        txtPrecoVendaProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoVendaProdutoEditarActionPerformed(evt);
            }
        });

        jLabel48.setText("Descrição");

        btnCancelarEditar.setText("Cancelar");
        btnCancelarEditar.setPreferredSize(new java.awt.Dimension(77, 45));
        btnCancelarEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarEditarActionPerformed(evt);
            }
        });

        btnSalvarProdutoEditar.setText("Salvar");
        btnSalvarProdutoEditar.setPreferredSize(new java.awt.Dimension(77, 45));
        btnSalvarProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarProdutoEditarActionPerformed(evt);
            }
        });

        txtIdProdutoEditar.setEditable(false);
        txtIdProdutoEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdProdutoEditarActionPerformed(evt);
            }
        });

        jLabel47.setText("Id");

        txtDescricaoProdutoEditar.setColumns(20);
        txtDescricaoProdutoEditar.setRows(5);
        jScrollPane2.setViewportView(txtDescricaoProdutoEditar);

        javax.swing.GroupLayout telaEditarProdutoLayout = new javax.swing.GroupLayout(telaEditarProduto.getContentPane());
        telaEditarProduto.getContentPane().setLayout(telaEditarProdutoLayout);
        telaEditarProdutoLayout.setHorizontalGroup(
            telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNomeProdutoEditar))
                    .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel40)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtFabricanteProdutoEditar))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel41)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCodigoProdutoEditar))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel42)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comboBoxCategoriaEditar, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel43)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPesoProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel44)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtUnidadeMedidaProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel45)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecoCompraProdutoEditar, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel46)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecoVendaProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)
                        .addComponent(jLabel47)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtIdProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(124, 124, 124))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaEditarProdutoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnSalvarProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelarEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel48)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );
        telaEditarProdutoLayout.setVerticalGroup(
            telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(telaEditarProdutoLayout.createSequentialGroup()
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCodigoProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41))
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39))
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFabricanteProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel40))
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxCategoriaEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel42)
                    .addComponent(jLabel43)
                    .addComponent(txtPesoProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel44)
                    .addComponent(txtUnidadeMedidaProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(txtPrecoCompraProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrecoVendaProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel46)
                    .addComponent(txtIdProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel47))
                .addGap(18, 18, 18)
                .addComponent(jLabel48)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(telaEditarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancelarEditar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalvarProdutoEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(0, 16, Short.MAX_VALUE))
        );

        jLabel50.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel50.setText("DETALHES DO PRODUTO");

        jLabel51.setText("Nome");

        txtNomeProdutoDetalhe.setEditable(false);

        jLabel52.setText("Fabricante");

        txtFabricanteProdutoDetalhe.setEditable(false);

        txtCodigoProdutoDetalhe.setEditable(false);

        jLabel53.setText("Codigo");

        jLabel54.setText("Categoria");

        jLabel55.setText("Peso");

        txtPesoProdutoDetalhe.setEditable(false);
        txtPesoProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel56.setText("Unidade de Medida");

        txtUnidadeMedidaProdutoDetalhe.setEditable(false);
        txtUnidadeMedidaProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUnidadeMedidaProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel57.setText("Preço de Compra");

        txtPrecoCompraProdutoDetalhe.setEditable(false);
        txtPrecoCompraProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoCompraProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel58.setText("Preço de Venda");

        txtPrecoVendaProdutoDetalhe.setEditable(false);
        txtPrecoVendaProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoVendaProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel59.setText("Estoque");

        txtEstoqueProdutoDetalhe.setEditable(false);
        txtEstoqueProdutoDetalhe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstoqueProdutoDetalheActionPerformed(evt);
            }
        });

        jLabel60.setText("Descrição");

        txtDescricaoProdutoDetalhe.setEditable(false);
        txtDescricaoProdutoDetalhe.setColumns(20);
        txtDescricaoProdutoDetalhe.setRows(5);
        jScrollPane4.setViewportView(txtDescricaoProdutoDetalhe);

        txtCategoriaProdutoDetalhe.setEditable(false);
        txtCategoriaProdutoDetalhe.setPreferredSize(new java.awt.Dimension(63, 30));

        javax.swing.GroupLayout telaDetalheProdutoLayout = new javax.swing.GroupLayout(telaDetalheProduto.getContentPane());
        telaDetalheProduto.getContentPane().setLayout(telaDetalheProdutoLayout);
        telaDetalheProdutoLayout.setHorizontalGroup(
            telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel50, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4)
                    .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel51)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNomeProdutoDetalhe))
                    .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel52)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtFabricanteProdutoDetalhe))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel53)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCodigoProdutoDetalhe))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel54)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCategoriaProdutoDetalhe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel55)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPesoProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel56)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtUnidadeMedidaProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel57)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecoCompraProdutoDetalhe, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel58)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecoVendaProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel59)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEstoqueProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel60)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        telaDetalheProdutoLayout.setVerticalGroup(
            telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(telaDetalheProdutoLayout.createSequentialGroup()
                .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCodigoProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel53))
                .addGap(18, 18, 18)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel51))
                .addGap(18, 18, 18)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFabricanteProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel52))
                .addGap(18, 18, 18)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel54)
                        .addComponent(jLabel55)
                        .addComponent(txtPesoProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel56)
                        .addComponent(txtUnidadeMedidaProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtCategoriaProdutoDetalhe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(telaDetalheProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel57)
                    .addComponent(txtPrecoCompraProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel59)
                    .addComponent(txtEstoqueProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrecoVendaProdutoDetalhe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel58))
                .addGap(18, 18, 18)
                .addComponent(jLabel60)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        painelPrincipal.setLayout(new java.awt.CardLayout());

        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel49, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1438, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel49, javax.swing.GroupLayout.DEFAULT_SIZE, 830, Short.MAX_VALUE)
        );

        painelPrincipal.add(jPanel1, "card4");

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("REGISTRAR VENDA");

        tabelaRegistrarVenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(tabelaRegistrarVenda);

        jLabel3.setText("Pesquisar Produto");

        jLabel4.setText("Produto");

        txtProdutoVenda.setToolTipText("produto");
        txtProdutoVenda.setName(""); // NOI18N

        jLabel6.setText("Quantidade");

        jLabel7.setText("Valor Pago");

        rbVendaPesoSim.setText("Sim");
        rbVendaPesoSim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbVendaPesoSimActionPerformed(evt);
            }
        });

        rbVendaPesoNao.setText("Não");
        rbVendaPesoNao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbVendaPesoNaoActionPerformed(evt);
            }
        });

        jLabel8.setText("Venda por Peso?");

        comboBoxPagamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pix", "Debito", "Credito a vista", "Credito parcelado", " " }));

        jLabel9.setText("Forma de pagamento");

        btnCancelarVenda.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\cancelar.png")); // NOI18N
        btnCancelarVenda.setText("Cancelar");
        btnCancelarVenda.setPreferredSize(new java.awt.Dimension(115, 45));
        btnCancelarVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarVendaActionPerformed(evt);
            }
        });

        btnVenderVenda.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\terminal-pos.png")); // NOI18N
        btnVenderVenda.setText("Vender");
        btnVenderVenda.setPreferredSize(new java.awt.Dimension(105, 45));

        panel1.setBackground(new java.awt.Color(0, 102, 255));
        panel1.setRoundBottomLeft(20);
        panel1.setRoundBottomRight(20);
        panel1.setRoundTopLeft(20);
        panel1.setRoundTopRight(20);

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel2.setText("PAGO:");

        jLabel25.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel25.setText("TOTAL:");

        jLabel10.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel10.setText("TROCO:");

        labelTroco.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        labelTroco.setText("0,00");

        labelTotalVenda.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        labelTotalVenda.setText("0,00");

        labelValorPago.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        labelValorPago.setText("0,00");

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(labelTroco))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                        .addComponent(jLabel25)
                        .addGap(18, 18, 18)
                        .addComponent(labelTotalVenda))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(labelValorPago)))
                .addContainerGap(199, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelValorPago, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelTotalVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelTroco, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(53, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout painelRegistrarVendaLayout = new javax.swing.GroupLayout(painelRegistrarVenda);
        painelRegistrarVenda.setLayout(painelRegistrarVendaLayout);
        painelRegistrarVendaLayout.setHorizontalGroup(
            painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelRegistrarVendaLayout.createSequentialGroup()
                .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(650, 650, 650))
                            .addComponent(txtProdutoVenda)
                            .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(597, 597, 597))
                            .addComponent(txtPesquisarProdutoVenda)
                            .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                        .addGap(4, 4, 4)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(29, 29, 29))
                                    .addComponent(spinnerQuantidadeVenda))
                                .addGap(18, 18, 18)
                                .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtValorPagoVenda)
                                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(134, 134, 134)))
                                .addGap(27, 27, 27)
                                .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                        .addComponent(rbVendaPesoSim, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(18, 18, 18)
                                        .addComponent(rbVendaPesoNao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(19, 19, 19)))
                                .addGap(256, 256, 256))
                            .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(579, 579, 579))
                            .addComponent(comboBoxPagamento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(31, 31, 31))
                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 610, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                        .addGap(354, 354, 354)
                        .addComponent(btnVenderVenda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelarVenda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(43, 43, 43))
        );
        painelRegistrarVendaLayout.setVerticalGroup(
            painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 654, Short.MAX_VALUE))
                    .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPesquisarProdutoVenda, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtProdutoVenda, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                        .addGap(30, 30, 30)
                        .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelRegistrarVendaLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rbVendaPesoSim, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(rbVendaPesoNao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addComponent(spinnerQuantidadeVenda)
                            .addComponent(txtValorPagoVenda))
                        .addGap(30, 30, 30)
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comboBoxPagamento, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
                        .addGap(68, 68, 68)
                        .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(painelRegistrarVendaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVenderVenda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCancelarVenda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(17, 17, 17))
        );

        painelPrincipal.add(painelRegistrarVenda, "card2");

        btnExcluirProduto.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\excluir.png")); // NOI18N
        btnExcluirProduto.setText("Excluir");
        btnExcluirProduto.setPreferredSize(new java.awt.Dimension(83, 45));
        btnExcluirProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirProdutoActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("LISTA DE PRODUTO");

        tabelaListaProduto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(tabelaListaProduto);

        btnDetalheProduto.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\pesquisa.png")); // NOI18N
        btnDetalheProduto.setText("Detalhes");
        btnDetalheProduto.setPreferredSize(new java.awt.Dimension(83, 45));
        btnDetalheProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetalheProdutoActionPerformed(evt);
            }
        });

        btnEditarProduto.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\editar-informacao.png")); // NOI18N
        btnEditarProduto.setText("Editar");
        btnEditarProduto.setPreferredSize(new java.awt.Dimension(83, 45));
        btnEditarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarProdutoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelListaProdutoLayout = new javax.swing.GroupLayout(painelListaProduto);
        painelListaProduto.setLayout(painelListaProdutoLayout);
        painelListaProdutoLayout.setHorizontalGroup(
            painelListaProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 1433, Short.MAX_VALUE)
            .addGroup(painelListaProdutoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(painelListaProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelListaProdutoLayout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 1409, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelListaProdutoLayout.createSequentialGroup()
                        .addComponent(btnDetalheProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluirProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))))
        );
        painelListaProdutoLayout.setVerticalGroup(
            painelListaProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelListaProdutoLayout.createSequentialGroup()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 668, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(painelListaProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDetalheProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEditarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluirProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        painelPrincipal.add(painelListaProduto, "card3");

        btnExcluirVenda.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\excluir.png")); // NOI18N
        btnExcluirVenda.setText("Excluir");
        btnExcluirVenda.setPreferredSize(new java.awt.Dimension(83, 45));
        btnExcluirVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirVendaActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("HISTORICO DE VENDAS");

        tabelaHistoricoVendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "PRODUTO", "VALOR PAGO", "QUANTIDADE", "FORMA DE PAGAMENTO"
            }
        ));
        jScrollPane7.setViewportView(tabelaHistoricoVendas);

        javax.swing.GroupLayout painelHistoricoVendasLayout = new javax.swing.GroupLayout(painelHistoricoVendas);
        painelHistoricoVendas.setLayout(painelHistoricoVendasLayout);
        painelHistoricoVendasLayout.setHorizontalGroup(
            painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, 1433, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelHistoricoVendasLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnExcluirVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
            .addGroup(painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(painelHistoricoVendasLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 1409, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        painelHistoricoVendasLayout.setVerticalGroup(
            painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelHistoricoVendasLayout.createSequentialGroup()
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 710, Short.MAX_VALUE)
                .addComponent(btnExcluirVenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
            .addGroup(painelHistoricoVendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(painelHistoricoVendasLayout.createSequentialGroup()
                    .addGap(79, 79, 79)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 675, Short.MAX_VALUE)
                    .addGap(76, 76, 76)))
        );

        painelPrincipal.add(painelHistoricoVendas, "card3");

        jLabel29.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("CONTROLE DE ESTOQUE");

        jLabel5.setText("Pesquisar Produto");

        txtPesquisaProdutoEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesquisaProdutoEstoqueActionPerformed(evt);
            }
        });

        txtProdutoEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProdutoEstoqueActionPerformed(evt);
            }
        });

        jLabel30.setText("Produto");

        jLabel31.setText("Quantidade");

        jLabel32.setText("Minimo");

        jLabel33.setText("Maximo");

        tabelaControleEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "CODIGO", "PRODUTO", "ESTOQUE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabelaControleEstoque);

        btnAddEstoque.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\adicionar.png")); // NOI18N
        btnAddEstoque.setText("Adicionar");
        btnAddEstoque.setPreferredSize(new java.awt.Dimension(119, 45));
        btnAddEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddEstoqueActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\cancelar.png")); // NOI18N
        jButton4.setText("Cancelar");
        jButton4.setPreferredSize(new java.awt.Dimension(115, 45));

        jLabel37.setText("Id");

        javax.swing.GroupLayout painelControleEstoqueLayout = new javax.swing.GroupLayout(painelControleEstoque);
        painelControleEstoque.setLayout(painelControleEstoqueLayout);
        painelControleEstoqueLayout.setHorizontalGroup(
            painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelControleEstoqueLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAddEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
            .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                        .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(610, 610, 610))
                            .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(spinnerQuantidadeEstoque)
                                    .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                                        .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(73, 73, 73)))
                                .addGap(18, 18, 18)
                                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                                        .addComponent(jLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(93, 93, 93))
                                    .addComponent(txtProdutoEstoqueMinimo))
                                .addGap(18, 18, 18)
                                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                                        .addComponent(jLabel33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(86, 86, 86))
                                    .addComponent(txtProdutoEstoqueMaximo))
                                .addGap(270, 270, 270))
                            .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtProdutoEstoque)
                                    .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                                        .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(510, 510, 510)))
                                .addGap(18, 18, 18)
                                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(painelControleEstoqueLayout.createSequentialGroup()
                                        .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(125, 125, 125))
                                    .addComponent(txtProdutoEstoqueID)))
                            .addComponent(txtPesquisaProdutoEstoque))
                        .addGap(678, 678, 678))))
        );
        painelControleEstoqueLayout.setVerticalGroup(
            painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelControleEstoqueLayout.createSequentialGroup()
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtPesquisaProdutoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtProdutoEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtProdutoEstoqueID))
                .addGap(18, 18, 18)
                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtProdutoEstoqueMinimo, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(spinnerQuantidadeEstoque, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(txtProdutoEstoqueMaximo, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(painelControleEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        painelPrincipal.add(painelControleEstoque, "card7");

        jLabel12.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("CADASTRAR PRODUTO");

        jLabel19.setText("Preço de Compra");

        txtEstoqueMaximoProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstoqueMaximoProdutoActionPerformed(evt);
            }
        });

        jLabel22.setText("Estoque");

        txtNomeProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeProdutoActionPerformed(evt);
            }
        });

        jLabel16.setText("Categoria");

        jLabel14.setText("Fabricante");

        btnCadastrarProduto.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\registro.png")); // NOI18N
        btnCadastrarProduto.setText("Cadastrar");
        btnCadastrarProduto.setPreferredSize(new java.awt.Dimension(83, 45));

        txtFabricanteProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFabricanteProdutoActionPerformed(evt);
            }
        });

        jLabel21.setText("Descrição");

        txtCodigoProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoProdutoActionPerformed(evt);
            }
        });

        txtPrecoCompraProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoCompraProdutoActionPerformed(evt);
            }
        });

        jLabel17.setText("Peso");

        txtEstoqueProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstoqueProdutoActionPerformed(evt);
            }
        });

        txtPesoProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoProdutoActionPerformed(evt);
            }
        });

        jLabel27.setText("Estoque Minimo");

        jLabel13.setText("Nome do Produto");

        btnCategoria.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\botao-adicionar.png")); // NOI18N
        btnCategoria.setContentAreaFilled(false);
        btnCategoria.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCategoriaActionPerformed(evt);
            }
        });

        txtUnidadeMedidaProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUnidadeMedidaProdutoActionPerformed(evt);
            }
        });

        btnCancelarProduto.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\cancelar.png")); // NOI18N
        btnCancelarProduto.setText("Cancelar");
        btnCancelarProduto.setPreferredSize(new java.awt.Dimension(79, 45));
        btnCancelarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarProdutoActionPerformed(evt);
            }
        });

        jLabel28.setText("Estoque Maximo");

        txtPrecoVendaProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoVendaProdutoActionPerformed(evt);
            }
        });

        txtDescricaoProduto.setColumns(20);
        txtDescricaoProduto.setRows(5);
        jScrollPane3.setViewportView(txtDescricaoProduto);

        jLabel18.setText("Unidade de medida");

        ComboBoxCategoria.setEditable(true);

        txtEstoqueMinimoProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstoqueMinimoProdutoActionPerformed(evt);
            }
        });

        jLabel15.setText("Codigo");

        jLabel20.setText("Preço de Venda");

        javax.swing.GroupLayout painelRegistrarProdutoLayout = new javax.swing.GroupLayout(painelRegistrarProduto);
        painelRegistrarProduto.setLayout(painelRegistrarProdutoLayout);
        painelRegistrarProdutoLayout.setHorizontalGroup(
            painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelRegistrarProdutoLayout.createSequentialGroup()
                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCadastrarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(178, 178, 178))
                                    .addComponent(txtEstoqueProduto, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(18, 18, 18)
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(156, 156, 156))
                                    .addComponent(txtEstoqueMinimoProduto, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(18, 18, 18)
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(156, 156, 156))
                                    .addComponent(txtEstoqueMaximoProduto, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(508, 508, 508))
                            .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                .addComponent(jLabel21)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtCodigoProduto, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(197, 197, 197)))
                                .addGap(18, 18, 18)
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(439, 439, 439))
                                    .addComponent(txtNomeProduto))
                                .addGap(18, 18, 18)
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(390, 390, 390))
                                    .addComponent(txtFabricanteProduto)))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(333, 333, 333))
                                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(ComboBoxCategoria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(47, 47, 47)))
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPesoProduto)
                                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(137, 137, 137)))
                                .addGap(18, 18, 18)
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtUnidadeMedidaProduto)
                                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(59, 59, 59)))
                                .addGap(18, 18, 18)
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPrecoCompraProduto)
                                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(108, 108, 108)))
                                .addGap(18, 18, 18)
                                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPrecoVendaProduto)
                                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                                        .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(118, 118, 118)))
                                .addGap(108, 108, 108)))))
                .addGap(83, 83, 83))
        );
        painelRegistrarProdutoLayout.setVerticalGroup(
            painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(37, 37, 37)
                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeProduto, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(txtFabricanteProduto, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(txtCodigoProduto, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtUnidadeMedidaProduto, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                            .addComponent(txtPrecoCompraProduto, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                            .addComponent(txtPrecoVendaProduto, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)))
                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(7, 7, 7)
                        .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPesoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btnCategoria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(ComboBoxCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(29, 29, 29)
                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelRegistrarProdutoLayout.createSequentialGroup()
                        .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEstoqueProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEstoqueMinimoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelRegistrarProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel28)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEstoqueMaximoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(28, 28, 28)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 383, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(painelRegistrarProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancelarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCadastrarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
        );

        painelPrincipal.add(painelRegistrarProduto, "card8");

        painelEstatisticas.setPreferredSize(new java.awt.Dimension(1414, 817));

        panel2.setBackground(new java.awt.Color(255, 102, 0));
        panel2.setPreferredSize(new java.awt.Dimension(346, 202));
        panel2.setRoundBottomLeft(20);
        panel2.setRoundBottomRight(20);
        panel2.setRoundTopLeft(20);
        panel2.setRoundTopRight(20);

        btnNovoProduto.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        btnNovoProduto.setForeground(new java.awt.Color(255, 102, 0));
        btnNovoProduto.setText("Novo Produto");

        labelProdutos.setFont(new java.awt.Font("Arial Black", 1, 48)); // NOI18N
        labelProdutos.setText("0");

        jLabel26.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Produtos");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnNovoProduto)
                            .addComponent(labelProdutos, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(141, Short.MAX_VALUE))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelProdutos, javax.swing.GroupLayout.PREFERRED_SIZE, 61, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnNovoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        panel3.setBackground(new java.awt.Color(0, 0, 255));
        panel3.setRoundBottomLeft(20);
        panel3.setRoundBottomRight(20);
        panel3.setRoundTopLeft(20);
        panel3.setRoundTopRight(20);

        jLabel62.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(255, 255, 255));
        jLabel62.setText("Vendas");

        labelVenda.setFont(new java.awt.Font("Arial Black", 1, 48)); // NOI18N
        labelVenda.setText("0");

        btnNovaVenda.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        btnNovaVenda.setForeground(new java.awt.Color(0, 0, 255));
        btnNovaVenda.setText("Nova Venda");
        btnNovaVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovaVendaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNovaVenda)
                    .addGroup(panel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(labelVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(166, Short.MAX_VALUE))
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 50, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(btnNovaVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        panel4.setBackground(new java.awt.Color(51, 255, 0));
        panel4.setRoundBottomLeft(20);
        panel4.setRoundBottomRight(20);
        panel4.setRoundTopLeft(20);
        panel4.setRoundTopRight(20);

        btnNovoProduto2.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        btnNovoProduto2.setForeground(new java.awt.Color(0, 255, 0));
        btnNovoProduto2.setText("Relatorio");
        btnNovoProduto2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoProduto2ActionPerformed(evt);
            }
        });

        labelTotal.setFont(new java.awt.Font("Arial Black", 1, 48)); // NOI18N
        labelTotal.setText("0,00");

        jLabel66.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 255, 255));
        jLabel66.setText("Lucro Total");

        javax.swing.GroupLayout panel4Layout = new javax.swing.GroupLayout(panel4);
        panel4.setLayout(panel4Layout);
        panel4Layout.setHorizontalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnNovoProduto2)
                    .addGroup(panel4Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(labelTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel66))
                .addContainerGap(162, Short.MAX_VALUE))
        );
        panel4Layout.setVerticalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel66, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 50, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(btnNovoProduto2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout painelEstatisticasLayout = new javax.swing.GroupLayout(painelEstatisticas);
        painelEstatisticas.setLayout(painelEstatisticasLayout);
        painelEstatisticasLayout.setHorizontalGroup(
            painelEstatisticasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelEstatisticasLayout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(104, 104, 104)
                .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 104, Short.MAX_VALUE)
                .addComponent(panel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80))
        );
        painelEstatisticasLayout.setVerticalGroup(
            painelEstatisticasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelEstatisticasLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(painelEstatisticasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(569, 569, 569))
        );

        painelPrincipal.add(painelEstatisticas, "card8");

        jButton2.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\impressora.png")); // NOI18N
        jButton2.setText("Imprimir");

        jLabel24.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("RELATORIO DO MÊS");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "VENDA", "LUCRO", "DATA"
            }
        ));
        jScrollPane8.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1409, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        painelRelatorio.addTab("Mês", jPanel4);

        jLabel63.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel63.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel63.setText("RELATORIO DA SEMANA");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "VENDA", "LUCRO", "DATA"
            }
        ));
        jScrollPane9.setViewportView(jTable2);

        jButton3.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\impressora.png")); // NOI18N
        jButton3.setText("Imprimir");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel63, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1409, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addComponent(jLabel63, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        painelRelatorio.addTab("Semana", jPanel5);

        jLabel64.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel64.setText("RELATORIO DO DIA");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "VENDA", "LUCRO", "DATA"
            }
        ));
        jScrollPane10.setViewportView(jTable3);

        jButton5.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\impressora.png")); // NOI18N
        jButton5.setText("Imprimir");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel64, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1409, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addComponent(jLabel64, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        painelRelatorio.addTab("Dia", jPanel6);

        painelPrincipal.add(painelRelatorio, "card9");

        jLabel61.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel61.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\ajudaVenda.png")); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1421, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 1421, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel61, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        painelSuporte.addTab("Como registrar venda", jPanel3);

        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel65.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\ajudaProduto.png")); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1421, Short.MAX_VALUE)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel65, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel65, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        painelSuporte.addTab("Como Cadastrar produto", jPanel8);

        jLabel67.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel67.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\ajudaEstoque.png")); // NOI18N

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1421, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel67, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel67, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        painelSuporte.addTab("Como atualizar o estoque", jPanel9);

        painelPrincipal.add(painelSuporte, "card10");

        Menubar.setMinimumSize(new java.awt.Dimension(64, 30));
        Menubar.setPreferredSize(new java.awt.Dimension(500, 30));

        Venda.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\pos-terminal.png")); // NOI18N
        Venda.setText("Venda");

        RegistrarVenda.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\caixa-registradora.png")); // NOI18N
        RegistrarVenda.setText("Registrar Venda");
        RegistrarVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistrarVendaActionPerformed(evt);
            }
        });
        Venda.add(RegistrarVenda);

        HistoricoVendas.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\pedido.png")); // NOI18N
        HistoricoVendas.setText("Historico de Vendas");
        HistoricoVendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HistoricoVendasActionPerformed(evt);
            }
        });
        Venda.add(HistoricoVendas);

        RelatorioVendas.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\recibo.png")); // NOI18N
        RelatorioVendas.setText("Relatorio de Vendas");
        RelatorioVendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RelatorioVendasActionPerformed(evt);
            }
        });
        Venda.add(RelatorioVendas);

        Menubar.add(Venda);

        Estoque.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\estoque-pronto.png")); // NOI18N
        Estoque.setText("Estoque");

        AdicionarProduto.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\novo-produto.png")); // NOI18N
        AdicionarProduto.setText("Adicionar Produto");
        Estoque.add(AdicionarProduto);

        ListaProduto.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\caracteristicas.png")); // NOI18N
        ListaProduto.setText("Lista de Produtos");
        Estoque.add(ListaProduto);

        ControleEstoque.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\preparar.png")); // NOI18N
        ControleEstoque.setText("Controle de Estoque");
        Estoque.add(ControleEstoque);

        Menubar.add(Estoque);

        Financeiro.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\lucro-financeiro.png")); // NOI18N
        Financeiro.setText("Financeiro");

        Estatisticas.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\estatisticas_1.png")); // NOI18N
        Estatisticas.setText("Estatisticas");
        Estatisticas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EstatisticasActionPerformed(evt);
            }
        });
        Financeiro.add(Estatisticas);

        Menubar.add(Financeiro);

        Configurações.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\configuracoes.png")); // NOI18N
        Configurações.setText("Configurações");

        Tema.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\tema.png")); // NOI18N
        Tema.setText("Tema");

        ModoClaro.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\sol.png")); // NOI18N
        ModoClaro.setText("Modo Claro");
        ModoClaro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModoClaroActionPerformed(evt);
            }
        });
        Tema.add(ModoClaro);

        ModoEscuro.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\lua.png")); // NOI18N
        ModoEscuro.setText("Modo Escuro");
        ModoEscuro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModoEscuroActionPerformed(evt);
            }
        });
        Tema.add(ModoEscuro);

        Configurações.add(Tema);

        Menubar.add(Configurações);

        Ajuda.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\ponto-de-informacao.png")); // NOI18N
        Ajuda.setText("Ajuda");

        Suporte.setIcon(new javax.swing.ImageIcon("D:\\SENAI\\sgve\\src\\main\\java\\resources\\suporte-tecnico.png")); // NOI18N
        Suporte.setText("Suporte");
        Suporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SuporteActionPerformed(evt);
            }
        });
        Ajuda.add(Suporte);

        Menubar.add(Ajuda);

        setJMenuBar(Menubar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelPrincipal, javax.swing.GroupLayout.PREFERRED_SIZE, 830, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RelatorioVendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RelatorioVendasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RelatorioVendasActionPerformed

    private void RegistrarVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistrarVendaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RegistrarVendaActionPerformed

    private void txtNomeProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeProdutoActionPerformed

    private void txtFabricanteProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFabricanteProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFabricanteProdutoActionPerformed

    private void txtCodigoProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoProdutoActionPerformed

    private void txtPesoProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoProdutoActionPerformed

    private void txtUnidadeMedidaProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUnidadeMedidaProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUnidadeMedidaProdutoActionPerformed

    private void txtPrecoCompraProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoCompraProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoCompraProdutoActionPerformed

    private void txtPrecoVendaProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoVendaProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoVendaProdutoActionPerformed

    private void txtEstoqueProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEstoqueProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEstoqueProdutoActionPerformed

    private void btnExcluirProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnExcluirProdutoActionPerformed

    private void btnDetalheProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetalheProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDetalheProdutoActionPerformed

    private void btnEditarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarProdutoActionPerformed

    private void btnExcluirVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirVendaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnExcluirVendaActionPerformed

    private void HistoricoVendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HistoricoVendasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HistoricoVendasActionPerformed

    private void ModoClaroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModoClaroActionPerformed
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatMacLightLaf());
                updateUIRecursively(painelPrincipal); // Atualiza o UI do painelPrincipal
                updateUIRecursively(painelRegistrarVenda);
                updateUIRecursively(painelListaProduto);
                updateUIRecursively(painelHistoricoVendas);
                updateUIRecursively(painelControleEstoque);
                updateUIRecursively(painelRegistrarProduto);
                updateUIRecursively(painelEstatisticas);
            } catch (UnsupportedLookAndFeelException ex) {
                Logger.getLogger(Dashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }//GEN-LAST:event_ModoClaroActionPerformed

    private void ModoEscuroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModoEscuroActionPerformed
         SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatMacDarkLaf());
                updateUIRecursively(Menubar);
                updateUIRecursively(painelPrincipal);
                updateUIRecursively(painelRegistrarVenda);
                updateUIRecursively(painelListaProduto);
                updateUIRecursively(painelHistoricoVendas);
                updateUIRecursively(painelControleEstoque);
                updateUIRecursively(painelRegistrarProduto);
                updateUIRecursively(painelEstatisticas);
            } catch (UnsupportedLookAndFeelException ex) {
                Logger.getLogger(Dashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }//GEN-LAST:event_ModoEscuroActionPerformed

    private void btnCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoriaActionPerformed
        telaCategoria.setLocationRelativeTo(null);
        telaCategoria.setVisible(true);
    }//GEN-LAST:event_btnCategoriaActionPerformed

    private void txtUnidadeMedidaProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUnidadeMedidaProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUnidadeMedidaProdutoDetalheActionPerformed

    private void txtPrecoCompraProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoCompraProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoCompraProdutoDetalheActionPerformed

    private void txtPrecoVendaProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoVendaProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoVendaProdutoDetalheActionPerformed

    private void txtPesoProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoProdutoDetalheActionPerformed

    private void txtEstoqueProdutoDetalheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEstoqueProdutoDetalheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEstoqueProdutoDetalheActionPerformed

    private void btnCancelarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarProdutoActionPerformed

    }//GEN-LAST:event_btnCancelarProdutoActionPerformed

    private void txtEstoqueMinimoProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEstoqueMinimoProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEstoqueMinimoProdutoActionPerformed

    private void txtEstoqueMaximoProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEstoqueMaximoProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEstoqueMaximoProdutoActionPerformed

    private void EstatisticasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EstatisticasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EstatisticasActionPerformed

    private void txtPesquisaProdutoEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisaProdutoEstoqueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesquisaProdutoEstoqueActionPerformed

    private void txtProdutoEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProdutoEstoqueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProdutoEstoqueActionPerformed

    private void btnAddEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddEstoqueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAddEstoqueActionPerformed

    private void txtIdProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdProdutoEditarActionPerformed

    private void btnSalvarProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSalvarProdutoEditarActionPerformed

    private void btnCancelarEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarEditarActionPerformed
        getTelaEditarProduto().setVisible(false);
    }//GEN-LAST:event_btnCancelarEditarActionPerformed

    private void txtPrecoVendaProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoVendaProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoVendaProdutoEditarActionPerformed

    private void txtPrecoCompraProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoCompraProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoCompraProdutoEditarActionPerformed

    private void txtUnidadeMedidaProdutoEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUnidadeMedidaProdutoEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUnidadeMedidaProdutoEditarActionPerformed

    private void btnCancelarVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarVendaActionPerformed
        
    }//GEN-LAST:event_btnCancelarVendaActionPerformed

    private void btnNovaVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovaVendaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNovaVendaActionPerformed

    private void btnNovoProduto2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoProduto2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNovoProduto2ActionPerformed

    private void SuporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SuporteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SuporteActionPerformed

    private void rbVendaPesoNaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbVendaPesoNaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbVendaPesoNaoActionPerformed

    private void rbVendaPesoSimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbVendaPesoSimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbVendaPesoSimActionPerformed

    public static void main(String args[]) {
        
        try {
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AdicionarProduto;
    private javax.swing.JMenu Ajuda;
    private javax.swing.JComboBox<String> ComboBoxCategoria;
    private javax.swing.JMenu Configurações;
    private javax.swing.JMenuItem ControleEstoque;
    private javax.swing.JMenuItem Estatisticas;
    private javax.swing.JMenu Estoque;
    private javax.swing.JMenu Financeiro;
    private javax.swing.JMenuItem HistoricoVendas;
    private javax.swing.JMenuItem ListaProduto;
    private javax.swing.JMenuBar Menubar;
    private javax.swing.JMenuItem ModoClaro;
    private javax.swing.JMenuItem ModoEscuro;
    private javax.swing.JMenuItem RegistrarVenda;
    private javax.swing.JMenuItem RelatorioVendas;
    private javax.swing.JMenuItem Suporte;
    private javax.swing.JMenu Tema;
    private javax.swing.JMenu Venda;
    private javax.swing.JButton btnAddEstoque;
    private javax.swing.JButton btnCadastrarProduto;
    private javax.swing.JButton btnCancelarCategoria;
    private javax.swing.JButton btnCancelarEditar;
    private javax.swing.JButton btnCancelarProduto;
    private javax.swing.JButton btnCancelarVenda;
    private javax.swing.JButton btnCategoria;
    private javax.swing.JButton btnDetalheProduto;
    private javax.swing.JButton btnEditarProduto;
    private javax.swing.JButton btnExcluirProduto;
    private javax.swing.JButton btnExcluirVenda;
    private javax.swing.JButton btnNovaVenda;
    private javax.swing.JButton btnNovoProduto;
    private javax.swing.JButton btnNovoProduto2;
    private javax.swing.JButton btnSalvarCategoria;
    private javax.swing.JButton btnSalvarProdutoEditar;
    private javax.swing.JButton btnVenderVenda;
    private javax.swing.JComboBox<String> comboBoxCategoriaEditar;
    private javax.swing.JComboBox<String> comboBoxPagamento;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JLabel labelProdutos;
    private javax.swing.JLabel labelTotal;
    private javax.swing.JLabel labelTotalVenda;
    private javax.swing.JLabel labelTroco;
    private javax.swing.JLabel labelValorPago;
    private javax.swing.JLabel labelVenda;
    private javax.swing.JPanel painelControleEstoque;
    private javax.swing.JPanel painelEstatisticas;
    private javax.swing.JPanel painelHistoricoVendas;
    private javax.swing.JPanel painelListaProduto;
    private javax.swing.JPanel painelPrincipal;
    private javax.swing.JPanel painelRegistrarProduto;
    private javax.swing.JPanel painelRegistrarVenda;
    private javax.swing.JTabbedPane painelRelatorio;
    private javax.swing.JTabbedPane painelSuporte;
    private view.Panel panel1;
    private view.Panel panel2;
    private view.Panel panel3;
    private view.Panel panel4;
    private javax.swing.JRadioButton rbVendaPesoNao;
    private javax.swing.JRadioButton rbVendaPesoSim;
    private javax.swing.JSpinner spinnerQuantidadeEstoque;
    private javax.swing.JSpinner spinnerQuantidadeVenda;
    private javax.swing.JTable tabelaControleEstoque;
    private javax.swing.JTable tabelaHistoricoVendas;
    private javax.swing.JTable tabelaListaProduto;
    private javax.swing.JTable tabelaRegistrarVenda;
    private javax.swing.JDialog telaCategoria;
    private javax.swing.JDialog telaDetalheProduto;
    private javax.swing.JDialog telaEditarProduto;
    private javax.swing.JTextField txtCategoriaProdutoDetalhe;
    private javax.swing.JTextField txtCodigoProduto;
    private javax.swing.JTextField txtCodigoProdutoDetalhe;
    private javax.swing.JTextField txtCodigoProdutoEditar;
    private javax.swing.JTextArea txtDescricaoProduto;
    private javax.swing.JTextArea txtDescricaoProdutoDetalhe;
    private javax.swing.JTextArea txtDescricaoProdutoEditar;
    private javax.swing.JTextField txtEstoqueMaximoProduto;
    private javax.swing.JTextField txtEstoqueMinimoProduto;
    private javax.swing.JTextField txtEstoqueProduto;
    private javax.swing.JTextField txtEstoqueProdutoDetalhe;
    private javax.swing.JTextField txtFabricanteProduto;
    private javax.swing.JTextField txtFabricanteProdutoDetalhe;
    private javax.swing.JTextField txtFabricanteProdutoEditar;
    private javax.swing.JTextField txtIdProdutoEditar;
    private javax.swing.JTextField txtNomeCategoria;
    private javax.swing.JTextField txtNomeProduto;
    private javax.swing.JTextField txtNomeProdutoDetalhe;
    private javax.swing.JTextField txtNomeProdutoEditar;
    private javax.swing.JTextField txtPesoProduto;
    private javax.swing.JTextField txtPesoProdutoDetalhe;
    private javax.swing.JTextField txtPesoProdutoEditar;
    private javax.swing.JTextField txtPesquisaProdutoEstoque;
    private javax.swing.JTextField txtPesquisarProdutoVenda;
    private javax.swing.JTextField txtPrecoCompraProduto;
    private javax.swing.JTextField txtPrecoCompraProdutoDetalhe;
    private javax.swing.JTextField txtPrecoCompraProdutoEditar;
    private javax.swing.JTextField txtPrecoVendaProduto;
    private javax.swing.JTextField txtPrecoVendaProdutoDetalhe;
    private javax.swing.JTextField txtPrecoVendaProdutoEditar;
    private javax.swing.JTextField txtProdutoEstoque;
    private javax.swing.JTextField txtProdutoEstoqueID;
    private javax.swing.JTextField txtProdutoEstoqueMaximo;
    private javax.swing.JTextField txtProdutoEstoqueMinimo;
    private javax.swing.JTextField txtProdutoVenda;
    private javax.swing.JTextField txtUnidadeMedidaProduto;
    private javax.swing.JTextField txtUnidadeMedidaProdutoDetalhe;
    private javax.swing.JTextField txtUnidadeMedidaProdutoEditar;
    private javax.swing.JTextField txtValorPagoVenda;
    // End of variables declaration//GEN-END:variables

    public JMenuItem getAdicionarProduto() {
        return AdicionarProduto;
    }

    public JMenuItem getControleEstoque() {
        return ControleEstoque;
    }

    public JMenu getEstoque() {
        return Estoque;
    }

    public JMenuItem getHistoricoVendas() {
        return HistoricoVendas;
    }

    public JMenuItem getListaProduto() {
        return ListaProduto;
    }

    public JMenuItem getRegistrarVenda() {
        return RegistrarVenda;
    }

    public JMenuItem getRelatorioVendas() {
        return RelatorioVendas;
    }

    public JMenu getVenda() {
        return Venda;
    }

    public JMenu getjMenu1() {
        return Financeiro;
    }

    public JMenu getjMenu2() {
        return Configurações;
    }

    public JMenuBar getjMenuBar2() {
        return Menubar;
    }

    public JPanel getPainelPrincipal() {
        return painelPrincipal;
    }

    public JPanel getPainelRegistrarVenda() {
        return painelRegistrarVenda;
    }

    public JMenu getAjuda() {
        return Ajuda;
    }

    public JPanel getPainelHistoricoVendas() {
        return painelHistoricoVendas;
    }

    public JPanel getPainelListaProduto() {
        return painelListaProduto;
    }

    public JPanel getPainelRegistrarProduto() {
        return painelRegistrarProduto;
    }

    public JPanel getPainelControleEstoque() {
        return painelControleEstoque;
    }

    public JButton getBtnCancelarCategoria() {
        return btnCancelarCategoria;
    }

    public JButton getBtnSalvarCategoria() {
        return btnSalvarCategoria;
    }

    public JDialog getTelaCategoria() {
        return telaCategoria;
    }

    public JTextField getTxtNomeCategoria() {
        return txtNomeCategoria;
    }

    public JButton getBtnCategoria() {
        return btnCategoria;
    }

    public JComboBox<String> getComboBoxCategoria() {
        return ComboBoxCategoria;
    }

    public JTextField getTxtCodigoProduto() {
        return txtCodigoProduto;
    }

    public JTextArea getTxtDescricaoProduto() {
        return txtDescricaoProduto;
    }

    public JTextField getTxtEstoqueProduto() {
        return txtEstoqueProduto;
    }

    public JTextField getTxtFabricanteProduto() {
        return txtFabricanteProduto;
    }

    public JTextField getTxtNomeProduto() {
        return txtNomeProduto;
    }

    public JTextField getTxtPesoProduto() {
        return txtPesoProduto;
    }

    public JTextField getTxtPrecoCompraProduto() {
        return txtPrecoCompraProduto;
    }

    public JTextField getTxtPrecoVendaProduto() {
        return txtPrecoVendaProduto;
    }

    public JTextField getTxtUnidadeMedidaProduto() {
        return txtUnidadeMedidaProduto;
    }

    public JTable getTabelaListaProduto() {
        return tabelaListaProduto;
    }

    public JTextField getTxtIdProdutoEditar() {
        return txtIdProdutoEditar;
    }
    
    public JComboBox<String> getComboBoxCategoriaEditar() {
        return comboBoxCategoriaEditar;
    }

    public JDialog getTelaEditarProduto() {
        return telaEditarProduto;
    }

    public JTextField getTxtCodigoProdutoEditar() {
        return txtCodigoProdutoEditar;
    }

    public JTextArea getTxtDescricaoProdutoEditar() {
        return txtDescricaoProdutoEditar;
    }

    public JTextField getTxtFabricanteProdutoEditar() {
        return txtFabricanteProdutoEditar;
    }

    public JTextField getTxtNomeProdutoEditar() {
        return txtNomeProdutoEditar;
    }

    public JTextField getTxtPesoProdutoEditar() {
        return txtPesoProdutoEditar;
    }

    public JTextField getTxtPrecoCompraProdutoEditar() {
        return txtPrecoCompraProdutoEditar;
    }

    public JTextField getTxtPrecoVendaProdutoEditar() {
        return txtPrecoVendaProdutoEditar;
    }

    public JTextField getTxtUnidadeMedidaProdutoEditar() {
        return txtUnidadeMedidaProdutoEditar;
    }

    public JButton getBtnEditarProduto() {
        return btnEditarProduto;
    }

    public JTextField getTxtCategoriaProdutoDetalhe() {
        return txtCategoriaProdutoDetalhe;
    }

    public JDialog getTelaDetalheProduto() {
        return telaDetalheProduto;
    }

    public JTextField getTxtCodigoProdutoDetalhe() {
        return txtCodigoProdutoDetalhe;
    }

    public JTextArea getTxtDescricaoProdutoDetalhe() {
        return txtDescricaoProdutoDetalhe;
    }
    
    public JTextField getTxtEstoqueProdutoDetalhe(){
        return txtEstoqueProdutoDetalhe;
    }

    public JTextField getTxtFabricanteProdutoDetalhe() {
        return txtFabricanteProdutoDetalhe;
    }

    public JTextField getTxtNomeProdutoDetalhe() {
        return txtNomeProdutoDetalhe;
    }

    public JTextField getTxtPesoProdutoDetalhe() {
        return txtPesoProdutoDetalhe;
    }

    public JTextField getTxtPrecoCompraProdutoDetalhe() {
        return txtPrecoCompraProdutoDetalhe;
    }

    public JTextField getTxtPrecoVendaProdutoDetalhe() {
        return txtPrecoVendaProdutoDetalhe;
    }

    public JTextField getTxtUnidadeMedidaProdutoDetalhe() {
        return txtUnidadeMedidaProdutoDetalhe;
    }

    public JTextField getTxtProdutoEstoqueMaximo() {
        return txtProdutoEstoqueMaximo;
    }

    public JTextField getTxtProdutoEstoqueMinimo() {
        return txtProdutoEstoqueMinimo;
    }

    public JSpinner getSpinnerQuantidadeEstoque() {
        return spinnerQuantidadeEstoque;
    }

    public JTable getTabelaControleEstoque() {
        return tabelaControleEstoque;
    }

    public JTable getTabelaRegistrarVenda() {
        return tabelaRegistrarVenda;
    }

    public JTextField getTxtPesquisaProdutoEstoque() {
        return txtPesquisaProdutoEstoque;
    }

    public JTextField getTxtProdutoEstoque() {
        return txtProdutoEstoque;
    }

    public JTextField getTxtPesquisarProdutoVenda() {
        return txtPesquisarProdutoVenda;
    }

    public JSpinner getSpinnerQuantidadeVenda() {
        return spinnerQuantidadeVenda;
    }

    public JTable getTabelaHistoricoVendas() {
        return tabelaHistoricoVendas;
    }

    public JTextField getTxtProdutoVenda() {
        return txtProdutoVenda;
    }

    public JTextField getTxtValorPagoVenda() {
        return txtValorPagoVenda;
    }

    public JComboBox<String> getComboBoxPagamento() {
        return comboBoxPagamento;
    }

    public JLabel getLabelTotalVenda() {
        return labelValorPago;
    }

    public JLabel getLabelTroco() {
        return labelTotalVenda;
    }

    public JLabel getLabelValorPago() {
        return labelTroco;
    }

    public JRadioButton getRbVendaPesoNao() {
        return rbVendaPesoNao;
    }

    public JRadioButton getRbVendaPesoSim() {
        return rbVendaPesoSim;
    }

    public JTextField getTxtEstoqueMaximoProduto() {
        return txtEstoqueMaximoProduto;
    }

    public JTextField getTxtEstoqueMinimoProduto() {
        return txtEstoqueMinimoProduto;
    }

    public JTextField getTxtProdutoEstoqueID() {
        return txtProdutoEstoqueID;
    }

    public JPanel getPainelEstatisticas() {
        return painelEstatisticas;
    }

    public JLabel getLabelProdutos() {
        return labelProdutos;
    }

    public JLabel getLabelTotal() {
        return labelTotal;
    }

    public JLabel getLabelVenda() {
        return labelVenda;
    }

    public JTabbedPane getPainelRelatorio() {
        return painelRelatorio;
    }

    public JTabbedPane getPainelSuporte() {
        return painelSuporte;
    }

    private void updateUIRecursively(Component comp) {
        if (comp == null) return;
    
        SwingUtilities.updateComponentTreeUI(comp);
    
        if (comp instanceof JComponent) {
            ((JComponent) comp).revalidate();
            ((JComponent) comp).repaint();
        }

        if (comp instanceof Container) {
            Component[] children = ((Container) comp).getComponents();
            for (Component child : children) {
                updateUIRecursively(child);
            }
        }
    }
    
}
